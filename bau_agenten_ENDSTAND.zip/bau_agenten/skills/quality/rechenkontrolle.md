---
name: rechenkontrolle
agent: quality
version: 1
status: active
---
Je Position GP = Menge x EP (auf 2 Nachkommastellen). Netto-Summe = Summe aller GP.
Richtpreise und fehlende Preise im Bericht ausweisen.
