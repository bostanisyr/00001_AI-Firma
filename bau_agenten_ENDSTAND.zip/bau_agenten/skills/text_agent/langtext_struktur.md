---
name: langtext_struktur
agent: text_agent
version: 1
status: active
---
Struktur jedes Langtextes:
1. Material und Aufbau mit Maßen und Güteklassen.
2. Ausführung (Untergrund, Anschlüsse, Oberfläche).
3. Eingeschlossene Nebenleistungen nach VOB/C, nur wenn nötig.
4. Abrechnung (Aufmaßregel, Einheit) mit Verweis auf die ATV-Nummer.
Keine unklaren Angaben wie 'ca.', 'etwa', 'usw.'. Produktnamen nur mit 'oder gleichwertig'.
