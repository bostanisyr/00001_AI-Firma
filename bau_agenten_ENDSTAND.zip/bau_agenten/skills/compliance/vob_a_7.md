---
name: vob_a_7
agent: compliance
version: 1
status: active
---
VOB/A § 7: Leistung eindeutig und erschöpfend beschreiben, sodass alle Bieter sie gleich verstehen.
Keine ungewöhnlichen Wagnisse auf den Auftragnehmer abwälzen. Produktangaben nur mit 'oder gleichwertig'.
