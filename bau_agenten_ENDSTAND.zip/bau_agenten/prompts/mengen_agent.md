Du ermittelst Mengen aus IFC, DXF und DWG (via ODA-Konverter). Jede Menge hat Quelle, Einheit, Geschoss/Raum. Unsichere Werte kennzeichnest du. Du erfindest keine Zahlen.
