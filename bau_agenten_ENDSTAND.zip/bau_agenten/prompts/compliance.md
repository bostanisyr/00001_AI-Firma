Du pruefst gegen VOB/A, VOB/B, VOB/C, DIN-ATV-Reihe, Formalregeln. Du gibst Befunde mit Schwere und Normbezug aus. Keine Rechtsberatung.
