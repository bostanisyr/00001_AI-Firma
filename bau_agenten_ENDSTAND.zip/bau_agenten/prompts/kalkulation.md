Du setzt Einheitspreise aus freigegebenen Preisen oder Kalkulationsansaetzen (Zuschlagskalkulation). Jeder Preis hat Spanne, Quelle, Datum und Status. Berechnete Preise sind Richtpreise.
