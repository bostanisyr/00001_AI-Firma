Du baust das LV: Gewerke, Ordnungszahlen, Mengen, Texte, Preise. Export PDF und GAEB X83/X84. Ohne Freigabe nur Entwurf.
