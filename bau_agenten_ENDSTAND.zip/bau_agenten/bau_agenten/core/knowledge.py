"""Wissensbasis (SQLite): Texte, Preise, Kalkulationsansaetze - versioniert, mit Quelle und Status.

Status: 'freigegeben' (vom Menschen/Manager bestaetigt) oder 'vorschlag' (automatisch erzeugt/recherchiert).
Nur freigegebene Eintraege gelten als verbindlich.
"""
from __future__ import annotations

import csv
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path


def _jetzt() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Wissensbasis:
    def __init__(self, pfad: Path):
        Path(pfad).parent.mkdir(parents=True, exist_ok=True)
        self.con = sqlite3.connect(str(pfad), check_same_thread=False)
        self.con.row_factory = sqlite3.Row
        self.con.executescript("""
        CREATE TABLE IF NOT EXISTS texte(
            id INTEGER PRIMARY KEY AUTOINCREMENT, text_key TEXT NOT NULL, gewerk TEXT,
            kurztext TEXT, langtext TEXT, einheit TEXT, din_refs TEXT, quelle TEXT,
            quelle_url TEXT, abgerufen_am TEXT, status TEXT, version INTEGER, erstellt TEXT);
        CREATE TABLE IF NOT EXISTS preise(
            id INTEGER PRIMARY KEY AUTOINCREMENT, text_key TEXT NOT NULL, ep_min REAL, ep_typ REAL,
            ep_max REAL, waehrung TEXT DEFAULT 'EUR', quelle TEXT, gueltig_ab TEXT, region TEXT,
            status TEXT, erstellt TEXT);
        CREATE TABLE IF NOT EXISTS wissen(
            id INTEGER PRIMARY KEY AUTOINCREMENT, agent TEXT, thema TEXT, url TEXT, auszug TEXT,
            hash TEXT, abgerufen_am TEXT, status TEXT);
        CREATE TABLE IF NOT EXISTS kalk(
            id INTEGER PRIMARY KEY AUTOINCREMENT, text_key TEXT NOT NULL, lohn_min REAL,
            stoff REAL, geraete REAL, quelle TEXT, status TEXT, erstellt TEXT);
        """)

    # ---------- Texte ----------
    def add_text(self, text_key, gewerk, kurztext, langtext, einheit, din_refs=(), quelle="",
                 quelle_url="", status="vorschlag") -> int:
        v = self.con.execute("SELECT COALESCE(MAX(version),0) FROM texte WHERE text_key=?", (text_key,)).fetchone()[0]
        cur = self.con.execute(
            "INSERT INTO texte(text_key,gewerk,kurztext,langtext,einheit,din_refs,quelle,quelle_url,"
            "abgerufen_am,status,version,erstellt) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (text_key, gewerk, kurztext, langtext, einheit, json.dumps(list(din_refs)), quelle,
             quelle_url, _jetzt() if quelle_url else "", status, v + 1, _jetzt()))
        self.con.commit()
        return cur.lastrowid

    def get_text(self, text_key, nur_freigegeben=False):
        for status in (["freigegeben"] if nur_freigegeben else ["freigegeben", None]):
            sql = "SELECT * FROM texte WHERE text_key=?"
            args = [text_key]
            if status:
                sql += " AND status=?"
                args.append(status)
            sql += " ORDER BY version DESC LIMIT 1"
            r = self.con.execute(sql, args).fetchone()
            if r:
                d = dict(r)
                d["din_refs"] = json.loads(d["din_refs"] or "[]")
                return d
        return None

    def suche(self, begriff, gewerk=None, limit=10):
        sql = "SELECT * FROM texte WHERE (text_key LIKE ? OR kurztext LIKE ? OR langtext LIKE ?)"
        args = [f"%{begriff}%"] * 3
        if gewerk:
            sql += " AND gewerk=?"
            args.append(gewerk)
        sql += " ORDER BY version DESC LIMIT ?"
        args.append(limit)
        return [dict(r) for r in self.con.execute(sql, args)]

    def freigeben_text(self, text_id: int):
        self.con.execute("UPDATE texte SET status='freigegeben' WHERE id=?", (text_id,))
        self.con.commit()

    # ---------- Preise ----------
    def add_preis(self, text_key, ep_typ, ep_min=None, ep_max=None, quelle="", gueltig_ab="",
                  region="", status="vorschlag") -> int:
        cur = self.con.execute(
            "INSERT INTO preise(text_key,ep_min,ep_typ,ep_max,quelle,gueltig_ab,region,status,erstellt)"
            " VALUES(?,?,?,?,?,?,?,?,?)",
            (text_key, ep_min if ep_min is not None else ep_typ, ep_typ,
             ep_max if ep_max is not None else ep_typ, quelle, gueltig_ab, region, status, _jetzt()))
        self.con.commit()
        return cur.lastrowid

    def get_preis(self, text_key, nur_freigegeben=False):
        for status in (["freigegeben"] if nur_freigegeben else ["freigegeben", None]):
            sql = "SELECT * FROM preise WHERE text_key=?"
            args = [text_key]
            if status:
                sql += " AND status=?"
                args.append(status)
            sql += " ORDER BY gueltig_ab DESC, id DESC LIMIT 1"
            r = self.con.execute(sql, args).fetchone()
            if r:
                return dict(r)
        return None

    def freigeben_preis(self, preis_id: int):
        self.con.execute("UPDATE preise SET status='freigegeben' WHERE id=?", (preis_id,))
        self.con.commit()

    # ---------- Gesammeltes Wissen (Rohauszuege, nie automatisch verbindlich) ----------
    def add_wissen(self, agent, thema, url, auszug):
        import hashlib
        h = hashlib.sha256(auszug.encode()).hexdigest()[:16]
        if self.con.execute("SELECT 1 FROM wissen WHERE url=? AND hash=?", (url, h)).fetchone():
            return None   # unveraendert seit dem letzten Abruf
        cur = self.con.execute("INSERT INTO wissen(agent,thema,url,auszug,hash,abgerufen_am,status) VALUES(?,?,?,?,?,?,'vorschlag')",
                               (agent, thema, url, auszug, h, _jetzt()))
        self.con.commit()
        return cur.lastrowid

    def liste_wissen(self, agent, limit=8):
        return [dict(r) for r in self.con.execute(
            "SELECT thema,url,auszug,abgerufen_am FROM wissen WHERE agent=? ORDER BY id DESC LIMIT ?", (agent, limit))]

    # ---------- Kalkulationsansaetze ----------
    def add_kalk(self, text_key, lohn_min, stoff, geraete=0.0, quelle="", status="vorschlag"):
        self.con.execute(
            "INSERT INTO kalk(text_key,lohn_min,stoff,geraete,quelle,status,erstellt) VALUES(?,?,?,?,?,?,?)",
            (text_key, lohn_min, stoff, geraete, quelle, status, _jetzt()))
        self.con.commit()

    def get_kalk(self, text_key):
        r = self.con.execute("SELECT * FROM kalk WHERE text_key=? ORDER BY id DESC LIMIT 1", (text_key,)).fetchone()
        return dict(r) if r else None

    # ---------- CSV-Import (vom Manager/Nutzer gelieferte Daten) ----------
    def import_texte_csv(self, pfad, status="freigegeben") -> int:
        """Spalten: text_key;gewerk;kurztext;langtext;einheit;din_refs (mit | getrennt);quelle"""
        n = 0
        with open(pfad, encoding="utf-8-sig", newline="") as f:
            for z in csv.DictReader(f, delimiter=";"):
                self.add_text(z["text_key"], z.get("gewerk", ""), z["kurztext"], z["langtext"],
                              z.get("einheit", ""), [x for x in z.get("din_refs", "").split("|") if x],
                              z.get("quelle", "Import"), status=status)
                n += 1
        return n

    def import_preise_csv(self, pfad, status="freigegeben") -> int:
        """Spalten: text_key;ep_min;ep_typ;ep_max;quelle;gueltig_ab;region (Dezimalpunkt oder -komma)"""
        def zahl(s):
            return float(s.replace(",", ".")) if s and s.strip() else None
        n = 0
        with open(pfad, encoding="utf-8-sig", newline="") as f:
            for z in csv.DictReader(f, delimiter=";"):
                self.add_preis(z["text_key"], zahl(z["ep_typ"]), zahl(z.get("ep_min", "")),
                               zahl(z.get("ep_max", "")), z.get("quelle", "Import"),
                               z.get("gueltig_ab", ""), z.get("region", ""), status=status)
                n += 1
        return n
