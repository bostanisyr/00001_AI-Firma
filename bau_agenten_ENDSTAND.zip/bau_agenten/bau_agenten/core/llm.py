"""Duenner Wrapper um die Anthropic-API. Ohne Key/SDK laeuft das System ohne LLM weiter."""
from __future__ import annotations

import os


class LLM:
    def __init__(self, cfg: dict):
        self.cfg = cfg.get("llm", {})
        self._client = None

    @property
    def verfuegbar(self) -> bool:
        if not self.cfg.get("enabled") or not os.environ.get("ANTHROPIC_API_KEY"):
            return False
        try:
            import anthropic  # noqa: F401
        except ImportError:
            return False
        return True

    def complete(self, system: str, user: str) -> str:
        if not self.verfuegbar:
            raise RuntimeError("LLM nicht verfuegbar (config llm.enabled, ANTHROPIC_API_KEY, anthropic-SDK).")
        import anthropic
        if self._client is None:
            self._client = anthropic.Anthropic()
        antwort = self._client.messages.create(
            model=self.cfg.get("model", "claude-sonnet-4-6"),
            max_tokens=int(self.cfg.get("max_tokens", 1500)),
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        return "".join(b.text for b in antwort.content if getattr(b, "type", "") == "text")
