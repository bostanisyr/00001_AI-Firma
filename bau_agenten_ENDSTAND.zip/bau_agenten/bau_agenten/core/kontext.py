"""Gemeinsamer Kontext: Konfiguration, Wissensbasis, LLM, Audit, Skills."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml

from .knowledge import Wissensbasis
from .llm import LLM
from ..manager.audit import AuditLog
from ..manager.improvement import SkillRegistry


@dataclass
class Kontext:
    basis: Path
    cfg: dict
    kb: Wissensbasis
    llm: LLM
    audit: AuditLog
    skills: SkillRegistry
    daten: Path

    @classmethod
    def laden(cls, basis, daten_dir=None) -> "Kontext":
        basis = Path(basis).resolve()
        cfg = yaml.safe_load((basis / "config.yaml").read_text(encoding="utf-8"))
        daten = Path(daten_dir) if daten_dir else basis / "daten"
        daten.mkdir(parents=True, exist_ok=True)
        return cls(
            basis=basis, cfg=cfg, kb=Wissensbasis(daten / "kb.sqlite"), llm=LLM(cfg),
            audit=AuditLog(daten / "audit.jsonl"),
            skills=SkillRegistry(basis / "skills", cfg.get("schutz", {}).get("geschuetzte_pfade", []), basis,
                                 cfg.get("verbesserung", {}).get("auto_uebernahme", False)),
            daten=daten)


def lade_prompt(basis, name: str, fallback: str = "") -> str:
    """Liest prompts/<name>.md (vom Buero-UI editierbar); ohne Datei gilt der Fallback."""
    p = Path(basis) / "prompts" / f"{name}.md"
    return p.read_text(encoding="utf-8").strip() if p.exists() else fallback
