"""Gemeinsame Datenmodelle aller Agenten."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, asdict
from typing import Optional

ERLAUBTE_EINHEITEN = {"m", "m2", "m3", "St", "psch", "kg", "t", "h"}


@dataclass
class Befund:
    schwere: str            # "Fehler" | "Warnung" | "Hinweis"
    agent: str
    code: str
    text: str
    referenz: str = ""      # z. B. "VOB/A § 7", "DIN 18340"
    bezug: str = ""         # OZ oder Element-ID


@dataclass
class Mengenposten:
    element_id: str
    name: str
    ifc_class: str
    geschoss: str
    raum: str
    menge_name: str         # z. B. NetSideArea, NetFloorArea, Umfang
    einheit: str            # m, m2, m3, St, kg
    wert: float
    quelle: str             # Datei + Herkunft
    hinweise: list = field(default_factory=list)


@dataclass
class Position:
    oz: str
    gewerk_id: str
    text_key: str
    kurztext: str
    langtext: str
    einheit: str
    menge: float
    ep: Optional[float] = None
    ep_min: Optional[float] = None
    ep_max: Optional[float] = None
    preis_status: str = "fehlt"     # fehlt | richtpreis | freigegeben
    text_status: str = "freigegeben"
    quellen: list = field(default_factory=list)
    din_refs: list = field(default_factory=list)
    menge_quelle: str = ""
    hinweise: list = field(default_factory=list)

    @property
    def gp(self) -> Optional[float]:
        if self.ep is None:
            return None
        return round(self.menge * self.ep, 2)


@dataclass
class LV:
    projekt: dict
    gewerke: list                    # [{"id": "01", "name": "...", "atv": "DIN 18340"}]
    positionen: list = field(default_factory=list)
    freigegeben: bool = False
    mwst: float = 0.19

    def netto(self) -> float:
        return round(sum(p.gp or 0.0 for p in self.positionen), 2)

    def mwst_betrag(self) -> float:
        return round(self.netto() * self.mwst, 2)

    def brutto(self) -> float:
        return round(self.netto() + self.mwst_betrag(), 2)

    def nach_gewerk(self) -> dict:
        res = {g["id"]: [] for g in self.gewerke}
        for p in self.positionen:
            res.setdefault(p.gewerk_id, []).append(p)
        return res

    def inhalt_hash(self) -> str:
        daten = [
            [p.oz, p.text_key, p.kurztext, p.langtext, p.einheit,
             round(p.menge, 3), p.ep]
            for p in self.positionen
        ]
        return hashlib.sha256(json.dumps(daten, sort_keys=True).encode()).hexdigest()

    def als_dict(self) -> dict:
        return {
            "projekt": self.projekt,
            "gewerke": self.gewerke,
            "positionen": [asdict(p) for p in self.positionen],
            "netto": self.netto(),
            "hash": self.inhalt_hash(),
        }
