"""LV als PDF (reportlab). Kopf mit Firma/Projekt, Positionen, Summen, ENTWURF-Vermerk."""
from __future__ import annotations

from datetime import date
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether


def eur(x) -> str:
    if x is None:
        return "-"
    return f"{x:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def menge_fmt(x) -> str:
    return f"{x:,.3f}".replace(",", "X").replace(".", ",").replace("X", ".")


def export_pdf(lv, pfad, firma: dict) -> str:
    stile = getSampleStyleSheet()
    klein = ParagraphStyle("klein", parent=stile["Normal"], fontSize=8, leading=10)
    fett = ParagraphStyle("fett", parent=klein, fontName="Helvetica-Bold")
    titel = ParagraphStyle("titel", parent=stile["Title"], fontSize=15, spaceAfter=4)
    entwurf = not lv.freigegeben

    def seitenrahmen(c, doc):
        c.saveState()
        c.setFont("Helvetica", 7)
        c.drawString(15 * mm, 8 * mm, f"{firma.get('name', '')} - {lv.projekt.get('name', '')}")
        c.drawRightString(195 * mm, 8 * mm, f"Seite {doc.page}")
        if entwurf:
            c.setFont("Helvetica-Bold", 9)
            c.setFillColor(colors.red)
            c.drawCentredString(105 * mm, 287 * mm, "ENTWURF - nicht freigegeben")
        c.restoreState()

    doc = SimpleDocTemplate(str(pfad), pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm,
                            topMargin=18 * mm, bottomMargin=16 * mm,
                            title=f"LV {lv.projekt.get('name', '')}", author=firma.get("name", ""))
    story = [Paragraph("Leistungsverzeichnis", titel)]
    p = lv.projekt
    kopf = [
        [Paragraph("Firma", fett), Paragraph(escape(firma.get("name", "")), klein),
         Paragraph("Projekt", fett), Paragraph(escape(p.get("name", "")), klein)],
        [Paragraph("Anschrift", fett), Paragraph(escape(firma.get("adresse", "")), klein),
         Paragraph("Projekt-Nr.", fett), Paragraph(escape(str(p.get("nr", ""))), klein)],
        [Paragraph("Auftraggeber", fett), Paragraph(escape(p.get("auftraggeber", "")), klein),
         Paragraph("Datum", fett), Paragraph(date.today().strftime("%d.%m.%Y"), klein)],
    ]
    t = Table(kopf, colWidths=[28 * mm, 62 * mm, 28 * mm, 62 * mm])
    t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
                           ("BACKGROUND", (0, 0), (0, -1), colors.whitesmoke),
                           ("BACKGROUND", (2, 0), (2, -1), colors.whitesmoke),
                           ("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story += [t, Spacer(1, 6 * mm)]

    spalten = [18 * mm, 84 * mm, 20 * mm, 12 * mm, 22 * mm, 24 * mm]
    for g in lv.gewerke:
        pos = lv.nach_gewerk().get(g["id"], [])
        if not pos:
            continue
        story.append(Paragraph(f"{g['id']} {escape(g['name'])}  ({escape(g.get('atv', ''))})", stile["Heading3"]))
        zeilen = [[Paragraph(h, fett) for h in ("OZ", "Leistung", "Menge", "Einh.", "EP [EUR]", "GP [EUR]")]]
        for x in pos:
            text = f"<b>{escape(x.kurztext)}</b><br/>{escape(x.langtext).replace(chr(10), '<br/>')}"
            if x.preis_status == "richtpreis":
                text += "<br/><i>Preis: Richtpreis, nicht freigegeben</i>"
            elif x.preis_status == "fehlt":
                text += "<br/><i>Preis fehlt</i>"
            zeilen.append([Paragraph(x.oz, klein), Paragraph(text, klein), Paragraph(menge_fmt(x.menge), klein),
                           Paragraph(x.einheit, klein), Paragraph(eur(x.ep), klein), Paragraph(eur(x.gp), klein)])
        summe = sum(x.gp or 0 for x in pos)
        zeilen.append(["", Paragraph(f"Summe {g['id']} {escape(g['name'])}", fett), "", "", "",
                       Paragraph(eur(round(summe, 2)), fett)])
        tab = Table(zeilen, colWidths=spalten, repeatRows=1)
        tab.setStyle(TableStyle([("GRID", (0, 0), (-1, -2), 0.3, colors.lightgrey),
                                 ("BACKGROUND", (0, 0), (-1, 0), colors.whitesmoke),
                                 ("LINEABOVE", (0, -1), (-1, -1), 0.8, colors.black),
                                 ("VALIGN", (0, 0), (-1, -1), "TOP")]))
        story += [tab, Spacer(1, 5 * mm)]

    summen = [["Nettosumme", eur(lv.netto())],
              [f"MwSt {lv.mwst * 100:.0f} %", eur(lv.mwst_betrag())],
              ["Bruttosumme", eur(lv.brutto())]]
    st = Table(summen, colWidths=[50 * mm, 30 * mm], hAlign="RIGHT")
    st.setStyle(TableStyle([("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
                            ("ALIGN", (1, 0), (1, -1), "RIGHT"), ("LINEABOVE", (0, -1), (-1, -1), 0.8, colors.black),
                            ("FONTSIZE", (0, 0), (-1, -1), 9)]))
    story.append(KeepTogether([st]))
    doc.build(story, onFirstPage=seitenrahmen, onLaterPages=seitenrahmen)
    return str(pfad)
