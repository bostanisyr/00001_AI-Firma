"""GAEB DA XML 3.3 Export (X83 Angebotsaufforderung, X84 Angebotsabgabe) + Strukturpruefung.

WICHTIG: Der Export folgt dem GAEB-DA-XML-3.3-Aufbau, ist aber NICHT zertifiziert. Vor produktiver Nutzung
immer (1) gegen das offizielle XSD von gaeb.de pruefen (pruefe_gaeb(..., xsd=...)) und (2) in einem
AVA-Programm oeffnen.
"""
from __future__ import annotations

from datetime import datetime

from lxml import etree

VERSION = "3.3"


def _ns(phase: str) -> str:
    return f"http://www.gaeb.de/GAEB_DA_XML/DA{phase}/{VERSION}"


def _fmt(x, nachkomma=3) -> str:
    return f"{x:.{nachkomma}f}"


def _text_block(parent, ns, text: str):
    for zeile in text.split("\n"):
        p = etree.SubElement(parent, f"{{{ns}}}p")
        s = etree.SubElement(p, f"{{{ns}}}span")
        s.text = zeile


def export_gaeb(lv, pfad, phase: str = "83") -> str:
    assert phase in ("83", "84"), "phase muss '83' oder '84' sein"
    ns = _ns(phase)
    q = lambda tag: f"{{{ns}}}{tag}"
    root = etree.Element(q("GAEB"), nsmap={None: ns})
    info = etree.SubElement(root, q("GAEBInfo"))
    jetzt = datetime.now()
    for tag, val in (("Version", VERSION), ("VersDate", "2021-05"), ("Date", jetzt.strftime("%Y-%m-%d")),
                     ("Time", jetzt.strftime("%H:%M:%S")), ("ProgSystem", "bau_agenten")):
        etree.SubElement(info, q(tag)).text = val
    prj = etree.SubElement(root, q("PrjInfo"))
    etree.SubElement(prj, q("NamePrj")).text = str(lv.projekt.get("nr") or lv.projekt.get("name", ""))[:20]
    etree.SubElement(prj, q("LblPrj")).text = lv.projekt.get("name", "")
    etree.SubElement(prj, q("Cur")).text = "EUR"
    etree.SubElement(prj, q("CurLbl")).text = "Euro"
    award = etree.SubElement(root, q("Award"))
    etree.SubElement(award, q("DP")).text = phase
    boq = etree.SubElement(award, q("BoQ"), ID="BoQ1")
    boq_info = etree.SubElement(boq, q("BoQInfo"))
    etree.SubElement(boq_info, q("Name")).text = "LV"
    etree.SubElement(boq_info, q("LblBoQ")).text = lv.projekt.get("name", "Leistungsverzeichnis")
    for typ, laenge in (("BoQLevel", "2"), ("Item", "4")):
        bk = etree.SubElement(boq_info, q("BoQBkdn"))
        etree.SubElement(bk, q("Type")).text = typ
        etree.SubElement(bk, q("Length")).text = laenge
        etree.SubElement(bk, q("Num")).text = "Yes"
    body = etree.SubElement(boq, q("BoQBody"))
    for g in lv.gewerke:
        pos = lv.nach_gewerk().get(g["id"], [])
        if not pos:
            continue
        cat = etree.SubElement(body, q("BoQCtgy"), RNoPart=g["id"], ID=f"C{g['id']}")
        lbl = etree.SubElement(cat, q("LblTx"))
        _text_block(lbl, ns, g["name"])
        cbody = etree.SubElement(cat, q("BoQBody"))
        items = etree.SubElement(cbody, q("Itemlist"))
        for x in pos:
            rno = x.oz.split(".")[-1]
            it = etree.SubElement(items, q("Item"), RNoPart=rno, ID=f"I{x.oz.replace('.', '_')}")
            etree.SubElement(it, q("Qty")).text = _fmt(x.menge)
            etree.SubElement(it, q("QU")).text = x.einheit
            if phase == "84" and x.ep is not None:
                etree.SubElement(it, q("UP")).text = _fmt(x.ep, 2)
                etree.SubElement(it, q("IT")).text = _fmt(x.gp, 2)
            desc = etree.SubElement(it, q("Description"))
            ct = etree.SubElement(desc, q("CompleteText"))
            ot = etree.SubElement(etree.SubElement(ct, q("OutlineText")), q("OutlTxt"))
            _text_block(etree.SubElement(ot, q("TextOutlTxt")), ns, x.kurztext)
            _text_block(etree.SubElement(etree.SubElement(ct, q("DetailTxt")), q("Text")), ns, x.langtext)
    etree.ElementTree(root).write(str(pfad), xml_declaration=True, encoding="UTF-8", pretty_print=True)
    return str(pfad)


def pruefe_gaeb(pfad, xsd: str | None = None) -> list:
    """Gibt eine Liste von Problemen zurueck (leer = bestanden)."""
    probleme = []
    try:
        baum = etree.parse(str(pfad))
    except etree.XMLSyntaxError as e:
        return [f"XML nicht wohlgeformt: {e}"]
    root = baum.getroot()
    ns = etree.QName(root).namespace or ""
    q = lambda tag: f"{{{ns}}}{tag}"
    if etree.QName(root).localname != "GAEB":
        probleme.append("Wurzelelement ist nicht GAEB")
    for pflicht in ("GAEBInfo", "PrjInfo", "Award"):
        if root.find(q(pflicht)) is None:
            probleme.append(f"Pflichtelement fehlt: {pflicht}")
    items = root.findall(f".//{q('Item')}")
    if not items:
        probleme.append("Keine Item-Elemente")
    ids = [i.get("ID") for i in items]
    if len(ids) != len(set(ids)):
        probleme.append("Doppelte Item-IDs")
    for i in items:
        for pflicht in ("Qty", "QU", "Description"):
            if i.find(q(pflicht)) is None:
                probleme.append(f"Item {i.get('ID')}: {pflicht} fehlt")
        if len(i.get("RNoPart", "")) != 4:
            probleme.append(f"Item {i.get('ID')}: RNoPart nicht 4-stellig")
    dp = root.findtext(f".//{q('DP')}")
    if dp == "84":
        s = 0.0
        for i in items:
            it = i.findtext(q("IT"))
            if it is not None:
                s += float(it)
    if xsd:
        schema = etree.XMLSchema(etree.parse(xsd))
        if not schema.validate(baum):
            probleme += [f"XSD: {e.message}" for e in schema.error_log][:20]
    return probleme
