"""Selbstentwicklung des Managers - kontrolliert:
Vorschlag -> Test an Referenzprojekten -> (menschliche) Freigabe -> Uebernahme mit Archiv/Rollback.
Geschuetzte Pfade (config schutz.geschuetzte_pfade) und Regeln/Preise/Rechte kann der Manager nie aendern.
"""
from __future__ import annotations

import json
import re
import shutil
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

import yaml


def _jetzt():
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")


class SkillRegistry:
    def __init__(self, skills_dir: Path, geschuetzt=(), basis: Path | None = None, auto_uebernahme=False):
        self.dir = Path(skills_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.basis = Path(basis) if basis else self.dir.parent
        self.geschuetzt = [(self.basis / g).resolve() for g in geschuetzt]
        self.auto = auto_uebernahme
        self._override = {}

    # ---------- Lesen ----------
    @staticmethod
    def _parse(text: str):
        text = text.replace("\r\n", "\n")
        m = re.match(r"^---\n(.*?)\n---\n(.*)$", text, re.S)
        if not m:
            return {}, text
        return yaml.safe_load(m.group(1)) or {}, m.group(2)

    def liste(self, agent: str | None = None) -> list:
        res = []
        for pfad in sorted(self.dir.glob("*/*.md")):
            if pfad.parent.name.startswith("_"):
                continue
            meta, _ = self._parse(pfad.read_text(encoding="utf-8"))
            if agent and pfad.parent.name != agent:
                continue
            res.append({"agent": pfad.parent.name, "name": pfad.stem, **meta})
        return res

    def aktiver_text(self, agent: str) -> str:
        teile = []
        for s in self.liste(agent):
            if s.get("status", "active") != "active":
                continue
            key = (agent, s["name"])
            if key in self._override:
                teile.append(self._override[key])
                continue
            _, body = self._parse((self.dir / agent / f"{s['name']}.md").read_text(encoding="utf-8"))
            teile.append(body.strip())
        for (a, n), t in self._override.items():
            if a == agent and not any(s["name"] == n for s in self.liste(agent)):
                teile.append(t)
        return "\n\n".join(teile)

    @contextmanager
    def mit_override(self, agent: str, name: str, text: str):
        self._override[(agent, name)] = text
        try:
            yield
        finally:
            self._override.pop((agent, name), None)

    # ---------- Aendern ----------
    def _pruefe_pfad(self, ziel: Path):
        ziel = ziel.resolve()
        if self.dir.resolve() not in ziel.parents:
            raise PermissionError("Zielpfad liegt ausserhalb des Skill-Verzeichnisses")
        for g in self.geschuetzt:
            if ziel == g or g in ziel.parents:
                raise PermissionError(f"Geschuetzter Pfad: {g}")

    def vorschlagen(self, agent: str, name: str, neuer_inhalt: str, grund: str) -> str:
        vid = f"{agent}__{name}__{_jetzt()}"
        vdir = self.dir / "_vorschlaege"
        vdir.mkdir(exist_ok=True)
        (vdir / f"{vid}.md").write_text(neuer_inhalt, encoding="utf-8")
        meta = {"id": vid, "agent": agent, "name": name, "grund": grund, "status": "offen", "bewertung": None}
        (vdir / f"{vid}.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        return vid

    def _lade_vorschlag(self, vid):
        vdir = self.dir / "_vorschlaege"
        return json.loads((vdir / f"{vid}.json").read_text(encoding="utf-8")), (vdir / f"{vid}.md").read_text(encoding="utf-8")

    def bewerten(self, vid: str, run_fn) -> dict:
        """run_fn(skill_text_oder_None) -> {'fehler': int, 'qa_fehler': int, 'abdeckung': float}
        Bestanden, wenn der Kandidat in keiner Kennzahl schlechter ist als der Ist-Stand und
        mindestens in einer besser."""
        meta, text = self._lade_vorschlag(vid)
        basis = run_fn(None)
        kand = {}
        with self.mit_override(meta["agent"], meta["name"], text):
            kand = run_fn(text)
        nicht_schlechter = (kand["fehler"] <= basis["fehler"] and kand["qa_fehler"] <= basis["qa_fehler"]
                            and kand["abdeckung"] >= basis["abdeckung"])
        besser = (kand["fehler"] < basis["fehler"] or kand["qa_fehler"] < basis["qa_fehler"]
                  or kand["abdeckung"] > basis["abdeckung"])
        meta["bewertung"] = {"basis": basis, "kandidat": kand, "bestanden": bool(nicht_schlechter and besser)}
        meta["status"] = "bestanden" if meta["bewertung"]["bestanden"] else "abgelehnt"
        (self.dir / "_vorschlaege" / f"{vid}.json").write_text(
            json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        return meta["bewertung"]

    def uebernehmen(self, vid: str, freigabe_durch: str | None = None) -> Path:
        meta, text = self._lade_vorschlag(vid)
        if meta["status"] != "bestanden":
            raise PermissionError("Vorschlag hat den Test an Referenzprojekten nicht bestanden")
        if not self.auto and not freigabe_durch:
            raise PermissionError("Menschliche Freigabe erforderlich (freigabe_durch)")
        ziel = self.dir / meta["agent"] / f"{meta['name']}.md"
        self._pruefe_pfad(ziel)
        ziel.parent.mkdir(parents=True, exist_ok=True)
        version = 1
        if ziel.exists():
            alt_meta, _ = self._parse(ziel.read_text(encoding="utf-8"))
            version = int(alt_meta.get("version", 1))
            archiv = self.dir / "_archiv"
            archiv.mkdir(exist_ok=True)
            shutil.copy(ziel, archiv / f"{meta['agent']}__{meta['name']}__v{version}.md")
            version += 1
        kopf = {"name": meta["name"], "agent": meta["agent"], "version": version, "status": "active",
                "freigabe": freigabe_durch or "auto", "grund": meta["grund"]}
        ziel.write_text("---\n" + yaml.safe_dump(kopf, allow_unicode=True) + "---\n" + text, encoding="utf-8")
        meta["status"] = "uebernommen"
        (self.dir / "_vorschlaege" / f"{vid}.json").write_text(
            json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        return ziel

    def zurueckrollen(self, agent: str, name: str) -> Path:
        archiv = sorted((self.dir / "_archiv").glob(f"{agent}__{name}__v*.md"))
        if not archiv:
            raise FileNotFoundError("Keine archivierte Version vorhanden")
        ziel = self.dir / agent / f"{name}.md"
        shutil.copy(archiv[-1], ziel)
        return ziel


def verbesserungsvorschlaege(ergebnis_kennzahlen: dict, befund_codes: dict, verlauf: list) -> list:
    """Regelbasierte Vorschlaege fuer den Projektbericht (ohne LLM). Reihenfolge = Prioritaet."""
    v = []
    k = ergebnis_kennzahlen
    if k.get("ohne_preis", 0):
        v.append(f"{k['ohne_preis']} Positionen ohne Preis: Preisliste per 'kb-import --preise' einspielen "
                 "oder Kalkulationsansaetze ergaenzen.")
    if k.get("ohne_text", 0):
        v.append(f"{k['ohne_text']} Regeln ohne Text: Texte importieren oder LLM-Entwurf aktivieren und freigeben.")
    if k.get("ungepruefte_texte", 0):
        v.append(f"{k['ungepruefte_texte']} Positionen mit ungeprueftem Text: pruefen und in der Wissensbasis freigeben.")
    for code, n in sorted(befund_codes.items(), key=lambda x: -x[1])[:3]:
        if n >= 3:
            v.append(f"Befund '{code}' trat {n}x auf: Skill/Textbaustein dazu verbessern (Vorschlag -> Test -> Freigabe).")
    if k.get("oeffnungsabzug_manuell", 0):
        v.append("Oeffnungsabzuege sind noch manuell: Regeln je Gewerk nach VOB/C als Skill ergaenzen.")
    if len(verlauf) >= 2 and verlauf[-1].get("befunde", 0) > verlauf[-2].get("befunde", 0):
        v.append("Befunde gegenueber dem Vorprojekt gestiegen: Ursachen im Audit-Trail pruefen.")
    return v
