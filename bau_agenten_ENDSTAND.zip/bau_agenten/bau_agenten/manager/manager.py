"""Manager (Orchestrator): steuert die Agenten, haelt Freigabe-Schranken ein, berichtet, entwickelt weiter."""
from __future__ import annotations

import json
import time
from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import yaml

from ..agents.compliance_agent import ComplianceAgent
from ..agents.lv_agent import LVAgent
from ..agents.pricing_agent import PricingAgent
from ..agents.qa_agent import QAAgent
from ..agents.quantity_agent import QuantityAgent
from ..agents.text_agent import TextAgent
from ..agents.visualization_agent import VisualizationAgent
from .improvement import verbesserungsvorschlaege
from ..core.kontext import lade_prompt


@dataclass
class Ergebnis:
    lv: object
    befunde: list
    kennzahlen: dict
    ausgaben: dict = field(default_factory=dict)
    final: bool = False
    bericht: str = ""


class Manager:
    name = "manager"

    def __init__(self, ctx):
        self.ctx = ctx
        self.mengen_agent = QuantityAgent(ctx)
        self.text_agent = TextAgent(ctx)
        self.preis_agent = PricingAgent(ctx)
        self.lv_agent = LVAgent(ctx, self.text_agent)
        self.compliance = ComplianceAgent(ctx)
        self.qa = QAAgent(ctx)
        self.viz = VisualizationAgent(ctx)

    # ---------- Pipeline ohne Export ----------
    def _pipeline(self, ordner: Path):
        ordner = Path(ordner)
        projekt = yaml.safe_load((ordner / "projekt.yaml").read_text(encoding="utf-8"))
        zeiten, befunde = {}, []

        def schritt(name, fn):
            t = time.perf_counter()
            res = fn()
            zeiten[name] = round(time.perf_counter() - t, 3)
            return res

        mengen = schritt("mengen", lambda: self.mengen_agent.run([ordner / e for e in projekt["eingaben"]]))
        befunde += self.mengen_agent.pruefe(mengen)
        regel_pfad = ordner / projekt["regeln"] if projekt.get("regeln") else self.ctx.basis / "regeln" / "mapping.yaml"
        regeln = yaml.safe_load(regel_pfad.read_text(encoding="utf-8"))
        lv, b = schritt("lv", lambda: self.lv_agent.baue_lv(
            {k: projekt.get(k, "") for k in ("name", "nr", "auftraggeber")}, mengen, regeln))
        befunde += b
        schritt("preise", lambda: self.preis_agent.preise_setzen(lv.positionen))
        befunde += schritt("compliance", lambda: self.compliance.pruefe(lv))
        befunde += schritt("qa", lambda: self.qa.pruefe(lv))
        return projekt, mengen, regeln, lv, befunde, zeiten

    @staticmethod
    def offene_punkte(lv) -> list:
        """Dinge, die eine Freigabe verhindern (Richtpreise, fehlende Preise, ungepruefte Texte)."""
        o = []
        for p in lv.positionen:
            if p.preis_status != "freigegeben":
                o.append(f"{p.oz}: Preis {p.preis_status}")
            if p.text_status != "freigegeben":
                o.append(f"{p.oz}: Text nicht freigegeben")
        return o

    # ---------- Freigabe (Mensch) ----------
    def freigeben(self, ordner, von: str) -> dict:
        ordner = Path(ordner)
        _, _, _, lv, befunde, _ = self._pipeline(ordner)
        fehler = [b for b in befunde if b.schwere == "Fehler"]
        if fehler:
            raise PermissionError(f"Freigabe nicht moeglich: {len(fehler)} Fehler offen "
                                  f"({', '.join(sorted({b.code for b in fehler}))})")
        offen = self.offene_punkte(lv)
        if offen:
            raise PermissionError("Freigabe nicht moeglich: " + "; ".join(offen[:5]))
        if not von.strip():
            raise PermissionError("Name der freigebenden Person fehlt")
        eintrag = {"freigegeben_von": von, "datum": datetime.now().isoformat(timespec="seconds"),
                   "lv_hash": lv.inhalt_hash()}
        (ordner / "freigabe.json").write_text(json.dumps(eintrag, indent=2), encoding="utf-8")
        self.ctx.audit.log(self.name, "freigabe", eintrag)
        return eintrag

    def _freigabe_gueltig(self, ordner: Path, lv) -> bool:
        f = ordner / "freigabe.json"
        if not f.exists():
            return False
        return json.loads(f.read_text(encoding="utf-8")).get("lv_hash") == lv.inhalt_hash()

    # ---------- Projektlauf ----------
    def run(self, ordner, mit_rundgang: bool = False) -> Ergebnis:
        ordner = Path(ordner)
        projekt, mengen, _, lv, befunde, zeiten = self._pipeline(ordner)
        hat_fehler = any(b.schwere == "Fehler" for b in befunde)
        gueltig = self._freigabe_gueltig(ordner, lv) or not self.ctx.cfg["freigabe"]["erforderlich"]
        lv.freigegeben = bool(gueltig and not hat_fehler and not self.offene_punkte(lv))
        ausgabe = ordner / "ausgabe"
        exp = self.lv_agent.exportiere(lv, ausgabe, self.ctx.cfg["firma"], "LV")
        ergebnis_dateien = dict(exp["dateien"])
        for p in exp["gaeb_probleme"]:
            from ..core.models import Befund
            befunde.append(Befund("Fehler", "lv_agent", "GAEB_STRUKTUR", p))
        (ausgabe / "lv_entwurf.json").write_text(
            json.dumps(lv.als_dict(), ensure_ascii=False, indent=2), encoding="utf-8")
        if mit_rundgang:
            ifcs = [e for e in projekt["eingaben"] if str(e).lower().endswith(".ifc")]
            if ifcs:
                v = self.viz.erzeuge_rundgang(ordner / ifcs[0], ausgabe / "rundgang", projekt.get("name", ""))
                ergebnis_dateien["rundgang"] = v["viewer"]
        kz = self._kennzahlen(lv, befunde, mengen, zeiten)
        erg = Ergebnis(lv=lv, befunde=befunde, kennzahlen=kz, ausgaben=ergebnis_dateien, final=lv.freigegeben)
        erg.bericht = self._bericht(ordner, projekt, erg, zeiten)
        self.ctx.audit.log(self.name, "projekt_abgeschlossen",
                           {"projekt": projekt.get("name"), "final": erg.final, "netto": lv.netto()})
        return erg

    # ---------- Kennzahlen und Bericht ----------
    def _kennzahlen(self, lv, befunde, mengen, zeiten) -> dict:
        codes = Counter(b.code for b in befunde)
        return {
            "positionen": len(lv.positionen),
            "ohne_preis": sum(1 for p in lv.positionen if p.preis_status == "fehlt"),
            "richtpreise": sum(1 for p in lv.positionen if p.preis_status == "richtpreis"),
            "ohne_text": codes.get("TEXT_FEHLT", 0),
            "ungepruefte_texte": sum(1 for p in lv.positionen if p.text_status != "freigegeben"),
            "oeffnungsabzug_manuell": sum(1 for p in lv.positionen if any("Oeffnungsabzuege" in h for h in p.hinweise)),
            "mengenposten": len(mengen),
            "fehler": sum(1 for b in befunde if b.schwere == "Fehler"),
            "warnungen": sum(1 for b in befunde if b.schwere == "Warnung"),
            "hinweise": sum(1 for b in befunde if b.schwere == "Hinweis"),
            "befunde": len(befunde),
            "netto": lv.netto(),
            "laufzeiten": zeiten,
            "befund_codes": dict(codes),
        }

    def _bericht(self, ordner: Path, projekt: dict, erg: Ergebnis, zeiten: dict) -> str:
        kz = erg.kennzahlen
        verlauf_pfad = self.ctx.daten / "projekt_kennzahlen.jsonl"
        verlauf = []
        if verlauf_pfad.exists():
            verlauf = [json.loads(z) for z in verlauf_pfad.read_text(encoding="utf-8").splitlines() if z.strip()]
        with open(verlauf_pfad, "a", encoding="utf-8") as f:
            f.write(json.dumps({"projekt": projekt.get("name"), "zeit": datetime.now().isoformat(timespec="seconds"),
                                "befunde": kz["befunde"], "fehler": kz["fehler"], "netto": kz["netto"]}) + "\n")
        vorschlaege = verbesserungsvorschlaege(kz, kz["befund_codes"], verlauf)
        z = [f"# Projektbericht: {projekt.get('name', '')}",
             f"Datum: {datetime.now():%d.%m.%Y %H:%M} | Status: "
             f"{'FREIGEGEBEN' if erg.final else 'ENTWURF (nicht freigegeben)'}", "",
             "## Kennzahlen",
             f"- Positionen: {kz['positionen']} | Mengenposten: {kz['mengenposten']}",
             f"- Ohne Preis: {kz['ohne_preis']} | Richtpreise: {kz['richtpreise']} | Ungepruefte Texte: {kz['ungepruefte_texte']}",
             f"- Befunde: {kz['fehler']} Fehler, {kz['warnungen']} Warnungen, {kz['hinweise']} Hinweise",
             f"- Netto: {kz['netto']:.2f} EUR",
             "- Laufzeiten [s]: " + ", ".join(f"{k} {v}" for k, v in zeiten.items()), "",
             "## Befunde"]
        if not erg.befunde:
            z.append("- keine")
        for b in sorted(erg.befunde, key=lambda b: {"Fehler": 0, "Warnung": 1, "Hinweis": 2}[b.schwere]):
            z.append(f"- [{b.schwere}] {b.agent}/{b.code} {b.bezug}: {b.text} {('(' + b.referenz + ')') if b.referenz else ''}")
        z += ["", "## Verbesserungsvorschlaege"] + ([f"- {v}" for v in vorschlaege] or ["- keine"])
        if self.ctx.llm.verfuegbar:
            try:
                txt = self.ctx.llm.complete(
                    lade_prompt(self.ctx.basis, "manager") + " Gib 3 konkrete, kurze Verbesserungsvorschlaege fuer Prozess und Agenten.", "\n".join(z))
                z += ["", "## LLM-Vorschlaege (ungeprueft)", txt]
            except Exception as e:  # Bericht darf nie am LLM scheitern
                z.append(f"- (LLM-Vorschlaege nicht verfuegbar: {e})")
        z += ["", "## Skills (aktiv)"] + [f"- {s['agent']}/{s['name']} v{s.get('version', 1)}"
                                         for s in self.ctx.skills.liste() if s.get("status", "active") == "active"]
        z += ["", "## Offen vor Freigabe",
              "- Mengen stichprobenartig gegen Plan pruefen", "- Preise und Richtpreise bestaetigen",
              "- Oeffnungsabzuege nach VOB/C pruefen", "- GAEB-Datei mit offiziellem XSD und in AVA-Software pruefen"]
        text = "\n".join(z)
        pfad = ordner / "ausgabe" / "bericht.md"
        pfad.write_text(text, encoding="utf-8")
        return str(pfad)

    # ---------- Selbstentwicklung ----------
    def neuer_skill(self, agent: str, name: str, inhalt: str, grund: str) -> str:
        vid = self.ctx.skills.vorschlagen(agent, name, inhalt, grund)
        self.ctx.audit.log(self.name, "skill_vorschlag", {"id": vid, "grund": grund})
        return vid

    def bewertungsfunktion(self, referenz_root: Path):
        """Fuehrt die Pipeline auf allen Referenzprojekten aus und liefert Kennzahlen fuer SkillRegistry.bewerten."""
        def run_fn(_skill_text):
            fehler = qa = pos = regeln_n = 0
            for ordner in sorted(Path(referenz_root).iterdir()):
                if not (ordner / "projekt.yaml").exists():
                    continue
                _, _, regeln, lv, befunde, _ = self._pipeline(ordner)
                fehler += sum(1 for b in befunde if b.schwere == "Fehler" and b.agent != "qa_agent")
                qa += sum(1 for b in befunde if b.schwere == "Fehler" and b.agent == "qa_agent")
                pos += len(lv.positionen)
                regeln_n += len(regeln["regeln"])
            return {"fehler": fehler, "qa_fehler": qa, "abdeckung": round(pos / max(regeln_n, 1), 3)}
        return run_fn

    def skill_pruefen_und_uebernehmen(self, vid: str, referenz_root: Path, freigabe_durch: str | None = None):
        bewertung = self.ctx.skills.bewerten(vid, self.bewertungsfunktion(referenz_root))
        self.ctx.audit.log(self.name, "skill_bewertet", {"id": vid, **bewertung})
        if not bewertung["bestanden"]:
            return bewertung, None
        pfad = self.ctx.skills.uebernehmen(vid, freigabe_durch)
        self.ctx.audit.log(self.name, "skill_uebernommen", {"id": vid, "pfad": str(pfad), "von": freigabe_durch})
        return bewertung, pfad
