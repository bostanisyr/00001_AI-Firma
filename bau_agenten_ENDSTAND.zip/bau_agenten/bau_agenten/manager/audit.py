"""Audit-Trail: jede Aktion eines Agenten wird protokolliert (JSONL, nur anhaengen)."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


class AuditLog:
    def __init__(self, pfad: Path):
        self.pfad = Path(pfad)
        self.pfad.parent.mkdir(parents=True, exist_ok=True)

    def log(self, agent: str, aktion: str, details: dict | None = None) -> None:
        details = details or {}
        eintrag = {
            "zeit": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "agent": agent,
            "aktion": aktion,
            "details": details,
            "hash": hashlib.sha256(
                json.dumps(details, sort_keys=True, default=str).encode()
            ).hexdigest()[:16],
        }
        with open(self.pfad, "a", encoding="utf-8") as f:
            f.write(json.dumps(eintrag, ensure_ascii=False, default=str) + "\n")

    def eintraege(self) -> list:
        if not self.pfad.exists():
            return []
        with open(self.pfad, encoding="utf-8") as f:
            return [json.loads(z) for z in f if z.strip()]
