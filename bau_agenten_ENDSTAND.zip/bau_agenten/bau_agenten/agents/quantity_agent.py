"""Agent 1 - Mengenermittlung aus IFC, DXF, DWG (via ODA-Konverter) und JSON."""
from __future__ import annotations

import json
import math
import re
import shutil
import subprocess
import tempfile
from collections import defaultdict
from pathlib import Path

from ..core.models import Befund, Mengenposten

_DXF_EINHEIT_ZU_METER = {1: 0.0254, 2: 0.3048, 4: 0.001, 5: 0.01, 6: 1.0}
_NAME_ZU_EINHEIT = [("Area", "m2"), ("Volume", "m3"), ("Length", "m"), ("Perimeter", "m"),
                    ("Count", "St"), ("Number", "St"), ("Weight", "kg")]
_IFC_IGNORIEREN = {"IfcOpeningElement", "IfcAnnotation", "IfcGrid", "IfcVirtualElement"}


def polygon_flaeche(punkte) -> float:
    """Shoelace-Formel."""
    n = len(punkte)
    s = 0.0
    for i in range(n):
        x1, y1 = punkte[i]
        x2, y2 = punkte[(i + 1) % n]
        s += x1 * y2 - x2 * y1
    return abs(s) / 2.0


def polygon_umfang(punkte) -> float:
    n = len(punkte)
    return sum(math.dist(punkte[i], punkte[(i + 1) % n]) for i in range(n))


class QuantityAgent:
    name = "mengen_agent"

    def __init__(self, ctx):
        self.ctx = ctx
        self.cfg = ctx.cfg

    # ---------- Einstieg ----------
    def run(self, pfade) -> list:
        mengen = []
        for p in map(Path, pfade):
            endung = p.suffix.lower()
            if endung == ".ifc":
                mengen += self._ifc(p)
            elif endung == ".dxf":
                mengen += self._dxf(p)
            elif endung == ".dwg":
                mengen += self._dwg(p)
            elif endung == ".json":
                mengen += self._json(p)
            else:
                raise ValueError(f"Nicht unterstuetztes Format: {p.name}")
        self.ctx.audit.log(self.name, "mengen_extrahiert", {"anzahl": len(mengen), "dateien": [str(p) for p in pfade]})
        return mengen

    # ---------- IFC ----------
    def _ifc(self, pfad: Path) -> list:
        try:
            import ifcopenshell
            import ifcopenshell.util.element as E
            import ifcopenshell.util.unit as U
        except ImportError as e:
            raise RuntimeError("ifcopenshell nicht installiert (pip install ifcopenshell).") from e
        modell = ifcopenshell.open(str(pfad))
        try:
            s = float(U.calculate_unit_scale(modell))   # Projekt-Laengeneinheit -> Meter
            skalen_hinweis = []
        except Exception:
            s = 1.0
            skalen_hinweis = ["Einheitenfaktor nicht ermittelt, Meter angenommen - pruefen"]
        faktor = {"m": s, "m2": s * s, "m3": s ** 3, "St": 1.0, "kg": 1.0}
        res = []
        for el in modell.by_type("IfcProduct"):
            if el.is_a() in _IFC_IGNORIEREN or el.is_a("IfcSpatialStructureElement") and not el.is_a("IfcSpace"):
                continue
            geschoss = self._geschoss(el, E)
            raum = (getattr(el, "LongName", None) or getattr(el, "Name", None) or "") if el.is_a("IfcSpace") else ""
            if el.is_a() in ("IfcDoor", "IfcWindow"):   # Stueckzahl: Qto enthaelt keinen Count
                res.append(Mengenposten(el.GlobalId, getattr(el, "Name", "") or "", el.is_a(), geschoss, "",
                                        "Count", "St", 1.0, f"{pfad.name}:Element", list(skalen_hinweis)))
            for pset_name, werte in E.get_psets(el).items():
                if not (pset_name.startswith("Qto_") or pset_name == "BaseQuantities"):
                    continue
                for mname, wert in werte.items():
                    if mname == "id" or not isinstance(wert, (int, float)):
                        continue
                    einheit = next((e for k, e in _NAME_ZU_EINHEIT if k in mname), None)
                    if einheit is None:
                        continue
                    res.append(Mengenposten(
                        element_id=el.GlobalId, name=getattr(el, "Name", "") or "", ifc_class=el.is_a(),
                        geschoss=geschoss, raum=raum, menge_name=mname, einheit=einheit,
                        wert=round(float(wert) * faktor[einheit], 4),
                        quelle=f"{pfad.name}:{pset_name}", hinweise=list(skalen_hinweis)))
        if not res:
            self.ctx.audit.log(self.name, "keine_qto", {"datei": pfad.name})
        return res

    @staticmethod
    def _geschoss(el, E) -> str:
        c = E.get_container(el)
        for _ in range(4):
            if c is None:
                return ""
            if c.is_a("IfcBuildingStorey"):
                return c.Name or ""
            c = E.get_container(c)
        return ""

    # ---------- DXF ----------
    def _dxf(self, pfad: Path) -> list:
        try:
            import ezdxf
        except ImportError as e:
            raise RuntimeError("ezdxf nicht installiert (pip install ezdxf).") from e
        doc = ezdxf.readfile(str(pfad))
        insunits = doc.header.get("$INSUNITS", 0)
        hinweise = []
        if insunits in _DXF_EINHEIT_ZU_METER:
            s = _DXF_EINHEIT_ZU_METER[insunits]
        else:
            fb = self.cfg["dxf"].get("einheit_fallback", "mm")
            s = {"mm": 0.001, "cm": 0.01, "m": 1.0}[fb]
            hinweise.append(f"DXF ohne Einheit, {fb} angenommen - pruefen")
        regex = re.compile(self.cfg["dxf"]["raum_layer_regex"])
        res = []
        for pl in doc.modelspace().query("LWPOLYLINE"):
            if not pl.closed or not regex.search(pl.dxf.layer):
                continue
            pts = [(x, y) for x, y, *_ in pl.get_points("xy")]
            if len(pts) < 3:
                continue
            hid = pl.dxf.handle
            res.append(Mengenposten(hid, f"Polylinie {hid}", "DXF-Raum", "", "", "NetFloorArea", "m2",
                                    round(polygon_flaeche(pts) * s * s, 4), f"{pfad.name}:{pl.dxf.layer}",
                                    list(hinweise)))
            res.append(Mengenposten(hid, f"Polylinie {hid}", "DXF-Raum", "", "", "Umfang", "m",
                                    round(polygon_umfang(pts) * s, 4), f"{pfad.name}:{pl.dxf.layer}",
                                    list(hinweise)))
        return res

    # ---------- DWG ----------
    def _dwg(self, pfad: Path) -> list:
        exe = self.cfg["dxf"].get("oda_converter") or shutil.which("ODAFileConverter")
        if not exe:
            raise RuntimeError("ODA File Converter nicht gefunden (config dxf.oda_converter). "
                               "DWG ist ein geschlossenes Format und muss zuerst nach DXF konvertiert werden.")
        with tempfile.TemporaryDirectory() as ein, tempfile.TemporaryDirectory() as aus:
            shutil.copy(pfad, Path(ein) / pfad.name)
            subprocess.run([exe, ein, aus, "ACAD2018", "DXF", "0", "1"], check=True, timeout=300)
            dxfs = list(Path(aus).glob("*.dxf"))
            if not dxfs:
                raise RuntimeError("DWG-Konvertierung lieferte keine DXF-Datei.")
            return self._dxf(dxfs[0])

    # ---------- JSON (manuell/aus anderen Quellen) ----------
    def _json(self, pfad: Path) -> list:
        daten = json.loads(pfad.read_text(encoding="utf-8"))
        return [Mengenposten(**d) for d in daten]

    # ---------- Plausibilitaet ----------
    def pruefe(self, mengen) -> list:
        b = []
        gesehen = set()
        for m in mengen:
            if m.wert <= 0:
                b.append(Befund("Fehler", self.name, "MENGE_NULL",
                                f"Menge <= 0: {m.menge_name}", bezug=m.element_id))
            if not m.einheit:
                b.append(Befund("Fehler", self.name, "EINHEIT_FEHLT", "Einheit fehlt", bezug=m.element_id))
            schluessel = (m.element_id, m.menge_name)
            if schluessel in gesehen:
                b.append(Befund("Warnung", self.name, "DOPPELT",
                                f"Doppelte Menge {m.menge_name}", bezug=m.element_id))
            gesehen.add(schluessel)
            for h in m.hinweise:
                b.append(Befund("Hinweis", self.name, "MENGE_HINWEIS", h, bezug=m.element_id))
        raeume = defaultdict(float)
        decken = defaultdict(float)
        for m in mengen:
            if m.ifc_class == "IfcSpace" and m.menge_name in ("NetFloorArea", "GrossFloorArea") \
                    and m.menge_name == "NetFloorArea":
                raeume[m.geschoss] += m.wert
            if m.ifc_class == "IfcSlab" and m.menge_name in ("GrossArea", "NetArea"):
                if m.menge_name == "GrossArea":
                    decken[m.geschoss] += m.wert
        if not raeume:
            b.append(Befund("Hinweis", self.name, "KEINE_RAEUME",
                            "Keine Raumflaechen (IfcSpace/NetFloorArea) gefunden - Raumbuch pruefen."))
        for g, summe in raeume.items():
            if g in decken and summe > decken[g] * self.cfg["toleranzen"]["raum_zu_geschoss_max"]:
                b.append(Befund("Warnung", self.name, "RAUM_GROESSER_DECKE",
                                f"Geschoss '{g}': Raumflaechen {summe:.1f} m2 > Deckenflaeche {decken[g]:.1f} m2",
                                "DIN 277"))
        return b

    def raumflaechen_je_geschoss(self, mengen) -> dict:
        res = defaultdict(float)
        for m in mengen:
            if m.menge_name == "NetFloorArea":
                res[m.geschoss or "-"] += m.wert
        return {k: round(v, 2) for k, v in res.items()}
