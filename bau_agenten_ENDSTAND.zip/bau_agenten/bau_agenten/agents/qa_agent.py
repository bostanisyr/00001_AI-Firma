"""QA-Agent - Endkontrolle: Rechenwerte, Platzhalter, Preisplausibilitaet, Vollstaendigkeit."""
from __future__ import annotations

import re

from ..core.models import Befund


class QAAgent:
    name = "qa_agent"

    def __init__(self, ctx):
        self.ctx = ctx
        self.tol = ctx.cfg["toleranzen"]

    def pruefe(self, lv) -> list:
        b = []
        for p in lv.positionen:
            if not p.kurztext.strip() or not p.langtext.strip():
                b.append(Befund("Fehler", self.name, "TEXT_LEER", "Kurz- oder Langtext leer", bezug=p.oz))
            if re.search(r"TODO|\{\{|\}\}|XXX|\?\?\?", p.kurztext + p.langtext):
                b.append(Befund("Fehler", self.name, "PLATZHALTER", "Platzhalter im Text", bezug=p.oz))
            if p.ep is None:
                b.append(Befund("Warnung", self.name, "PREIS_FEHLT", "Kein Einheitspreis", bezug=p.oz))
                continue
            if p.preis_status == "richtpreis":
                b.append(Befund("Hinweis", self.name, "RICHTPREIS", "Preis ist ein Richtpreis (nicht freigegeben)",
                                bezug=p.oz))
            if p.gp is not None and abs(p.gp - round(p.menge * p.ep, 2)) > 0.01:
                b.append(Befund("Fehler", self.name, "GP_RECHENFEHLER", "GP != Menge x EP", bezug=p.oz))
            if p.ep_min and p.ep_max:
                if p.ep < p.ep_min * self.tol["preis_unten"] or p.ep > p.ep_max * self.tol["preis_oben"]:
                    b.append(Befund("Warnung", self.name, "PREIS_AUSREISSER",
                                    f"EP {p.ep} ausserhalb Spanne {p.ep_min}-{p.ep_max}", bezug=p.oz))
        summe = round(sum(p.gp or 0 for p in lv.positionen), 2)
        if abs(summe - lv.netto()) > 0.01:
            b.append(Befund("Fehler", self.name, "SUMME", "Netto-Summe stimmt nicht"))
        if not lv.positionen:
            b.append(Befund("Fehler", self.name, "LEER", "LV enthaelt keine Positionen"))
        self.ctx.audit.log(self.name, "geprueft", {"befunde": len(b)})
        return b
