"""Agent 2 - Ausschreibungstexte (Kurz-/Langtext). Lernt aus Manager-Daten und freigegebenen Quellen."""
from __future__ import annotations

import re
from html.parser import HTMLParser
from urllib.parse import urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener

from ..core.kontext import lade_prompt

PROMPT_STANDARD = ("Du schreibst deutsche Ausschreibungstexte (Kurztext max. 70 Zeichen, Langtext) nach "
                   "VOB/A und VOB/C (ATV). Neutral, eindeutig, ohne Werbesprache.")


class _Textextraktor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.teile, self._skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._skip += 1

    def handle_endtag(self, tag):
        if tag in ("script", "style") and self._skip:
            self._skip -= 1

    def handle_data(self, d):
        if not self._skip and d.strip():
            self.teile.append(d.strip())


def quelle_erlaubt(url: str, whitelist) -> bool:
    host = (urlparse(url).hostname or "").lower()
    return any(host == d or host.endswith("." + d) for d in whitelist)


class _NurWhitelist(HTTPRedirectHandler):
    def __init__(self, whitelist):
        self.wl = whitelist

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not quelle_erlaubt(newurl, self.wl):
            raise PermissionError(f"Weiterleitung auf Quelle ausserhalb der Whitelist: {newurl}")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def hole_auszug(url: str, whitelist, limit: int = 1500) -> str:
    """Laedt eine Seite (nur Whitelist, auch bei Weiterleitungen) und gibt einen kurzen Rohtext-Auszug zurueck."""
    if not quelle_erlaubt(url, whitelist):
        raise PermissionError(f"Quelle nicht in quellen_whitelist: {url}")
    req = Request(url, headers={"User-Agent": "bau-agenten/1.0"})
    with build_opener(_NurWhitelist(whitelist)).open(req, timeout=20) as r:
        html = r.read(2_000_000).decode("utf-8", errors="replace")
    p = _Textextraktor()
    p.feed(html)
    return " ".join(p.teile)[:limit]


class TextAgent:
    name = "text_agent"

    def __init__(self, ctx):
        self.ctx = ctx

    # ---------- Abruf-Reihenfolge: freigegebene Texte -> Vorschlaege -> LLM-Entwurf ----------
    def text_fuer(self, text_key: str, gewerk: str = "", beschreibung: str = ""):
        eintrag = self.ctx.kb.get_text(text_key)
        if eintrag:
            return eintrag
        if self.ctx.llm.verfuegbar:
            return self._llm_entwurf(text_key, gewerk, beschreibung)
        return None

    def _llm_entwurf(self, text_key, gewerk, beschreibung):
        system = lade_prompt(self.ctx.basis, "text_agent", PROMPT_STANDARD) + "\n\n" + self.ctx.skills.aktiver_text("text_agent")
        vorlagen = self.ctx.kb.suche(gewerk or text_key.split("_")[0], limit=3)
        beispiele = "\n\n".join(f"KURZTEXT: {v['kurztext']}\nLANGTEXT: {v['langtext']}" for v in vorlagen)
        user = (f"Position: {text_key}\nGewerk: {gewerk}\nBeschreibung: {beschreibung}\n\n"
                f"Beispiele aus der Wissensbasis:\n{beispiele}\n\n"
                "Antworte exakt im Format:\nKURZTEXT: ...\nLANGTEXT: ...\nEINHEIT: ...\nNORMEN: a; b")
        antwort = self.ctx.llm.complete(system, user)
        felder = {}
        for key in ("KURZTEXT", "LANGTEXT", "EINHEIT", "NORMEN"):
            m = re.search(rf"{key}:\s*(.*?)(?=\n[A-Z]+:|\Z)", antwort, re.S)
            felder[key] = m.group(1).strip() if m else ""
        if not felder["KURZTEXT"] or not felder["LANGTEXT"]:
            self.ctx.audit.log(self.name, "llm_parse_fehler", {"text_key": text_key})
            return None
        tid = self.ctx.kb.add_text(text_key, gewerk, felder["KURZTEXT"], felder["LANGTEXT"], felder["EINHEIT"],
                                   [n.strip() for n in felder["NORMEN"].split(";") if n.strip()],
                                   quelle="LLM-Entwurf (ungeprueft)", status="vorschlag")
        self.ctx.audit.log(self.name, "llm_entwurf", {"text_key": text_key, "id": tid})
        return self.ctx.kb.get_text(text_key)

    # ---------- Recherche in Whitelist-Quellen ----------
    def recherchiere(self, url: str, text_key: str, gewerk: str = "") -> dict:
        wl = self.ctx.cfg.get("quellen_whitelist", [])
        if not quelle_erlaubt(url, wl):
            raise PermissionError(f"Quelle nicht in quellen_whitelist: {url}")
        req = Request(url, headers={"User-Agent": "bau-agenten/1.0"})
        with build_opener(_NurWhitelist(wl)).open(req, timeout=20) as r:
            html = r.read(2_000_000).decode("utf-8", errors="replace")
        p = _Textextraktor()
        p.feed(html)
        auszug = " ".join(p.teile)[:2000]
        tid = self.ctx.kb.add_text(text_key, gewerk, "(Recherche - Rohauszug)", auszug, "", [],
                                   quelle="Web-Recherche (nur Rohmaterial, umformulieren, Urheberrecht beachten)",
                                   quelle_url=url, status="vorschlag")
        self.ctx.audit.log(self.name, "recherche", {"url": url, "text_key": text_key, "id": tid})
        return {"id": tid, "url": url, "zeichen": len(auszug)}

    # ---------- Lernen aus menschlicher Korrektur ----------
    def lerne_aus_korrektur(self, text_key, kurztext, langtext, grund=""):
        alt = self.ctx.kb.get_text(text_key) or {}
        tid = self.ctx.kb.add_text(text_key, alt.get("gewerk", ""), kurztext, langtext,
                                   alt.get("einheit", ""), alt.get("din_refs", []),
                                   quelle=f"Korrektur: {grund}", status="vorschlag")
        self.ctx.audit.log(self.name, "korrektur_gelernt", {"text_key": text_key, "id": tid, "grund": grund})
        return tid
