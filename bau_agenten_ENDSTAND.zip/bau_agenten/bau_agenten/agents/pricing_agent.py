"""Kalkulations-Agent - setzt Einheitspreise (EP) je Position mit Spanne, Quelle und Status."""
from __future__ import annotations


class PricingAgent:
    name = "kalkulations_agent"

    def __init__(self, ctx):
        self.ctx = ctx
        self.k = ctx.cfg["kalkulation"]

    def ep_aus_kalk(self, lohn_min, stoff, geraete=0.0) -> float:
        """Vereinfachte Zuschlagskalkulation: EKT -> +BGK -> +AGK -> +W+G. Saetze sind Platzhalter."""
        ekt = lohn_min / 60.0 * self.k["stundenverrechnungssatz"] + stoff + geraete
        sk = ekt * (1 + self.k["bgk"]) * (1 + self.k["agk"])
        return round(sk * (1 + self.k["wagnis_gewinn"]), 2)

    def preise_setzen(self, positionen) -> int:
        gesetzt = 0
        for p in positionen:
            preis = self.ctx.kb.get_preis(p.text_key)
            if preis:
                p.ep, p.ep_min, p.ep_max = preis["ep_typ"], preis["ep_min"], preis["ep_max"]
                p.preis_status = "freigegeben" if preis["status"] == "freigegeben" else "richtpreis"
                p.quellen.append(f"Preis: {preis['quelle'] or 'k.A.'} ({preis['gueltig_ab'] or 'o. Datum'})")
                gesetzt += 1
                continue
            kalk = self.ctx.kb.get_kalk(p.text_key)
            if kalk:
                ep = self.ep_aus_kalk(kalk["lohn_min"], kalk["stoff"], kalk["geraete"] or 0.0)
                sp = self.k["kalk_spanne"]
                p.ep, p.ep_min, p.ep_max = ep, round(ep * (1 - sp), 2), round(ep * (1 + sp), 2)
                p.preis_status = "richtpreis"
                p.quellen.append(f"Preis: berechnet aus Kalkulationsansatz ({kalk['quelle'] or 'k.A.'}), "
                                 "Zuschlagssaetze Standardannahme")
                gesetzt += 1
            else:
                p.preis_status = "fehlt"
        self.ctx.audit.log(self.name, "preise_gesetzt", {"gesetzt": gesetzt, "gesamt": len(positionen)})
        return gesetzt
