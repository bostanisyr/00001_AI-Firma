"""Agent 3 - LV-Aufbau: Texte + Preise + Mengen -> LV, Export als PDF und GAEB."""
from __future__ import annotations

from pathlib import Path

from ..core.models import LV, Position, Befund
from ..exporte.pdf import export_pdf
from ..exporte.gaeb import export_gaeb, pruefe_gaeb


class LVAgent:
    name = "lv_agent"

    def __init__(self, ctx, text_agent):
        self.ctx = ctx
        self.text_agent = text_agent

    def baue_lv(self, projekt: dict, mengen, regeln: dict):
        """regeln = Inhalt von regeln/mapping.yaml (gewerke + regeln). Gibt (LV, Befunde) zurueck."""
        gewerke = regeln["gewerke"]
        atv = {g["id"]: g.get("atv", "") for g in gewerke}
        lv = LV(projekt=projekt, gewerke=gewerke, mwst=self.ctx.cfg["kalkulation"]["mwst"])
        befunde, zaehler = [], {}
        for r in regeln["regeln"]:
            treffer = [m for m in mengen
                       if m.menge_name == r["menge_name"]
                       and (not r.get("ifc_class") or m.ifc_class == r["ifc_class"])
                       and (not r.get("name_contains") or r["name_contains"].lower() in m.name.lower())]
            summe = sum(m.wert for m in treffer) * float(r.get("faktor", 1.0))
            if not treffer or summe <= 0:
                befunde.append(Befund("Hinweis", self.name, "KEINE_MENGE",
                                      f"Regel '{r['text_key']}': keine passenden Mengen gefunden", bezug=r["text_key"]))
                continue
            eintrag = self.text_agent.text_fuer(r["text_key"], r["gewerk"], r.get("beschreibung", ""))
            if not eintrag:
                befunde.append(Befund("Fehler", self.name, "TEXT_FEHLT",
                                      f"Kein Text fuer '{r['text_key']}' in Wissensbasis", bezug=r["text_key"]))
                continue
            gid = r["gewerk"]
            zaehler[gid] = zaehler.get(gid, 0) + 1
            refs = list(eintrag.get("din_refs", []))
            if atv.get(gid) and atv[gid] not in refs:
                refs.append(atv[gid])
            hinweise = []
            if r.get("oeffnungsabzug", "manuell") == "manuell":
                hinweise.append("Oeffnungsabzuege nach VOB/C nicht berechnet - manuell pruefen")
            lv.positionen.append(Position(
                oz=f"{gid}.{zaehler[gid] * 10:04d}", gewerk_id=gid, text_key=r["text_key"],
                kurztext=eintrag["kurztext"], langtext=eintrag["langtext"],
                einheit=eintrag.get("einheit") or r.get("einheit", "m2"), menge=round(summe, 3),
                text_status=eintrag["status"], din_refs=refs,
                quellen=[f"Text: {eintrag.get('quelle') or 'k.A.'} v{eintrag['version']}"],
                menge_quelle=", ".join(sorted({m.quelle for m in treffer}))[:200], hinweise=hinweise))
        self.ctx.audit.log(self.name, "lv_gebaut", {"positionen": len(lv.positionen)})
        return lv, befunde

    def exportiere(self, lv: LV, ziel: Path, firma: dict, basisname: str = "LV") -> dict:
        ziel = Path(ziel)
        ziel.mkdir(parents=True, exist_ok=True)
        suffix = "" if lv.freigegeben else "_ENTWURF"
        ausgaben = {
            "pdf": export_pdf(lv, ziel / f"{basisname}{suffix}.pdf", firma),
            "gaeb_x83": export_gaeb(lv, ziel / f"{basisname}{suffix}.x83", "83"),
            "gaeb_x84": export_gaeb(lv, ziel / f"{basisname}{suffix}.x84", "84"),
        }
        probleme = pruefe_gaeb(ausgaben["gaeb_x83"]) + pruefe_gaeb(ausgaben["gaeb_x84"])
        self.ctx.audit.log(self.name, "exportiert", {"dateien": ausgaben, "gaeb_probleme": probleme})
        return {"dateien": ausgaben, "gaeb_probleme": probleme}
