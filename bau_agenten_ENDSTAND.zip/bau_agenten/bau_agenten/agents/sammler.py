"""Sammel-Lauf: jeder Agent liest seine Quellen aus quellen.yaml (nur Whitelist) und legt kurze Rohauszuege
als 'vorschlag' in der Wissensbasis ab. Nichts davon wird automatisch in LV, Texte oder Preise uebernommen."""
from __future__ import annotations

import yaml

from .text_agent import hole_auszug


def sammle(ctx, agent: str | None = None) -> dict:
    quellen = yaml.safe_load((ctx.basis / "quellen.yaml").read_text(encoding="utf-8")) or {}
    wl = ctx.cfg.get("quellen_whitelist", [])
    ergebnis = {}
    for name, liste in quellen.items():
        if agent and name != agent:
            continue
        for q in liste or []:
            ctx.audit.log(name, "liest_quelle", {"url": q["url"]})
            try:
                text = hole_auszug(q["url"], wl)
                neu = ctx.kb.add_wissen(name, q.get("thema", ""), q["url"], text)
                e = {"url": q["url"], "ok": True, "zeichen": len(text), "neu": neu is not None}
            except Exception as ex:   # eine kaputte Quelle stoppt den Lauf nicht
                e = {"url": q["url"], "ok": False, "fehler": f"{type(ex).__name__}: {ex}"[:160]}
            ergebnis.setdefault(name, []).append(e)
    ctx.audit.log("manager", "sammlung_abgeschlossen", {"quellen": sum(len(v) for v in ergebnis.values())})
    return ergebnis
