"""Compliance-Agent - regelbasierte Pruefung gegen VOB/A, VOB/C (ATV) und Formalregeln.

Kein Ersatz fuer eine rechtliche Pruefung. Regeln stehen in regeln/compliance.yaml.
"""
from __future__ import annotations

import re

import yaml

from ..core.models import Befund


class ComplianceAgent:
    name = "compliance_agent"

    def __init__(self, ctx):
        self.ctx = ctx
        with open(ctx.basis / "regeln" / "compliance.yaml", encoding="utf-8") as f:
            self.r = yaml.safe_load(f)

    def pruefe(self, lv) -> list:
        b = []
        atv = {g["id"]: g.get("atv", "") for g in lv.gewerke}
        oz_gesehen = set()
        for p in lv.positionen:
            text = f"{p.kurztext}\n{p.langtext}"
            if p.oz in oz_gesehen:
                b.append(Befund("Fehler", self.name, "OZ_DOPPELT", "Ordnungszahl doppelt", bezug=p.oz))
            oz_gesehen.add(p.oz)
            if len(p.kurztext) > self.r["kurztext_max_zeichen"]:
                b.append(Befund("Warnung", self.name, "KURZTEXT_LANG",
                                f"Kurztext {len(p.kurztext)} Zeichen (max. {self.r['kurztext_max_zeichen']})",
                                "GAEB DA XML", p.oz))
            if p.einheit not in self.r["erlaubte_einheiten"]:
                b.append(Befund("Fehler", self.name, "EINHEIT", f"Einheit '{p.einheit}' nicht zulaessig", bezug=p.oz))
            if p.menge <= 0:
                b.append(Befund("Fehler", self.name, "MENGE", "Menge <= 0", bezug=p.oz))
            for wort in self.r["unklare_formulierungen"]:
                if re.search(rf"(?<!\w){re.escape(wort)}(?!\w)", text, re.I):
                    b.append(Befund("Warnung", self.name, "UNKLAR",
                                    f"Unklare Formulierung '{wort}' - Leistung eindeutig beschreiben",
                                    "VOB/A § 7", p.oz))
            for wort in self.r["wagnis_formulierungen"]:
                if wort.lower() in text.lower():
                    b.append(Befund("Fehler", self.name, "WAGNIS",
                                    f"Moegliche Wagnisabwaelzung: '{wort}'", "VOB/A § 7", p.oz))
            if any(m.lower() in text.lower() for m in self.r["produktmerkmale"]) \
                    and self.r["gleichwertig_text"] not in text.lower():
                b.append(Befund("Warnung", self.name, "PRODUKT_OHNE_GLEICHWERTIG",
                                "Produktangabe ohne 'oder gleichwertig'", "VOB/A § 7", p.oz))
            if self.r["atv_pflicht"] and atv.get(p.gewerk_id) and atv[p.gewerk_id] not in p.din_refs:
                b.append(Befund("Warnung", self.name, "ATV_FEHLT",
                                f"Gewerk-ATV {atv[p.gewerk_id]} nicht referenziert", "VOB/C", p.oz))
            if p.text_status != "freigegeben":
                b.append(Befund("Warnung", self.name, "TEXT_UNGEPRUEFT",
                                "Text ist nur Vorschlag/Entwurf, nicht freigegeben", bezug=p.oz))
        self.ctx.audit.log(self.name, "geprueft", {"befunde": len(b)})
        return b
