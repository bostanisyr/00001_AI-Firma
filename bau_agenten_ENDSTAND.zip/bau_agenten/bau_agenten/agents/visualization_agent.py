"""Agent 4 - 3D-Rundgang (Three.js) und 4D-Bauphasen aus IFC + LV.

Ehrliche Einordnung: Das Ergebnis ist ein interaktives 3D-Modell mit Begehung (WASD + Maus) und einer
Bauphasen-Zeitleiste - kein KI-generiertes Fotorealismus-Video. Die Realitaetsnaehe haengt vom IFC-Modell ab
(Materialien, Detaillierung). Voraussetzung: IfcConvert (aus IfcOpenShell) zur Umwandlung IFC -> GLB.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

PHASEN = [
    {"name": "1 Rohbau", "klassen": ["IfcSlab", "IfcWall", "IfcColumn", "IfcBeam", "IfcStair", "IfcFooting"]},
    {"name": "2 Dach", "klassen": ["IfcRoof"]},
    {"name": "3 Fenster und Fassade", "klassen": ["IfcWindow", "IfcCurtainWall"]},
    {"name": "4 Ausbau", "klassen": ["IfcDoor", "IfcCovering", "IfcRailing", "IfcFurnishingElement"]},
]

VIEWER = """<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Rundgang __TITEL__</title>
<style>html,body{margin:0;height:100%;background:#1b1d21;color:#eee;font:14px system-ui}
#ui{position:fixed;left:8px;top:8px;background:#0008;padding:8px 12px;border-radius:6px}
#hint{position:fixed;left:50%;top:45%;transform:translate(-50%);background:#000a;padding:12px;border-radius:6px}</style>
</head><body><div id="ui"><b>__TITEL__</b><br>Phase: <span id="pn"></span><br>
<input id="sl" type="range" min="0" max="__MAX__" value="__MAX__" style="width:220px"></div>
<div id="hint">Klicken zum Starten - WASD bewegen, Maus umsehen, Esc beenden</div>
<script type="importmap">{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js",
"three/addons/":"https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/"}}</script>
<script type="module">
import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {PointerLockControls} from 'three/addons/controls/PointerLockControls.js';
const PHASEN=__PHASEN__;
const scene=new THREE.Scene();scene.background=new THREE.Color(0x1b1d21);
const cam=new THREE.PerspectiveCamera(70,innerWidth/innerHeight,0.05,500);cam.position.set(0,1.7,5);
const r=new THREE.WebGLRenderer({antialias:true});r.setSize(innerWidth,innerHeight);document.body.appendChild(r.domElement);
scene.add(new THREE.HemisphereLight(0xffffff,0x444455,1.1));
const sun=new THREE.DirectionalLight(0xffffff,1.2);sun.position.set(10,20,10);scene.add(sun);
const ctl=new PointerLockControls(cam,r.domElement);
document.addEventListener('click',()=>{ctl.lock();document.getElementById('hint').style.display='none'});
const k={};addEventListener('keydown',e=>k[e.code]=true);addEventListener('keyup',e=>k[e.code]=false);
let knoten=[];
new GLTFLoader().load('modell.glb',g=>{scene.add(g.scene);g.scene.traverse(o=>{if(o.isMesh)knoten.push(o)});zeige(__MAX__);
 const box=new THREE.Box3().setFromObject(g.scene);const c=box.getCenter(new THREE.Vector3());cam.position.set(c.x,box.min.y+1.7,box.max.z+3);},
 undefined,e=>{document.getElementById('hint').textContent='modell.glb nicht geladen - Seite ueber http-Server oeffnen (python -m http.server)'});
function zeige(i){document.getElementById('pn').textContent=PHASEN[i].name;
 const sichtbar=new Set(PHASEN.slice(0,i+1).flatMap(p=>p.klassen));
 const alle=new Set(PHASEN.flatMap(p=>p.klassen));
 knoten.forEach(m=>{let n=(m.name+' '+(m.parent?m.parent.name:'')).toLowerCase();
  const kl=[...alle].find(c=>n.includes(c.toLowerCase()));m.visible=kl?sichtbar.has(kl):true;});}
document.getElementById('sl').oninput=e=>zeige(+e.target.value);
const clock=new THREE.Clock();
(function loop(){requestAnimationFrame(loop);const d=clock.getDelta()*3;
 if(k.KeyW)ctl.moveForward(d);if(k.KeyS)ctl.moveForward(-d);if(k.KeyA)ctl.moveRight(-d);if(k.KeyD)ctl.moveRight(d);
 r.render(scene,cam);})();
addEventListener('resize',()=>{cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix();r.setSize(innerWidth,innerHeight)});
</script></body></html>"""


class VisualizationAgent:
    name = "visualisierungs_agent"

    def __init__(self, ctx):
        self.ctx = ctx

    def erzeuge_rundgang(self, ifc_pfad, ziel: Path, titel: str = "Projekt") -> dict:
        ziel = Path(ziel)
        ziel.mkdir(parents=True, exist_ok=True)
        exe = self.ctx.cfg.get("ifc", {}).get("ifcconvert") or shutil.which("IfcConvert")
        hinweise = []
        glb = ziel / "modell.glb"
        if exe:
            subprocess.run([exe, str(ifc_pfad), str(glb)], check=True, timeout=1800)
        else:
            hinweise.append("IfcConvert nicht gefunden: modell.glb manuell erzeugen "
                            "(IfcConvert modell.ifc modell.glb) und neben viewer.html legen.")
        html = (VIEWER.replace("__TITEL__", titel).replace("__PHASEN__", json.dumps(PHASEN))
                .replace("__MAX__", str(len(PHASEN) - 1)))
        (ziel / "viewer.html").write_text(html, encoding="utf-8")
        hinweise.append("Phasenzuordnung nutzt Klassennamen in den GLB-Knoten; fehlen sie, bleibt alles sichtbar.")
        self.ctx.audit.log(self.name, "rundgang", {"ziel": str(ziel), "glb": glb.exists()})
        return {"viewer": str(ziel / "viewer.html"), "glb": str(glb) if glb.exists() else None, "hinweise": hinweise}
