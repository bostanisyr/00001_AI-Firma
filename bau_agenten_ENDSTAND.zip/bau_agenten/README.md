# Bau-Agenten – digitale Planungs- und Ausschreibungsfirma

Ein Manager steuert 7 Fachagenten (Mengen, Texte, Kalkulation, LV, Compliance, Qualität, 3D) und erstellt
Leistungsverzeichnisse als PDF und GAEB (X83/X84). Menschliche Freigabe und Audit-Protokoll sind eingebaut.

## Start
```
pip install -r requirements.txt
python main.py buero        # Büro im Browser: http://127.0.0.1:8080
python main.py demo         # Demoprojekt in der Konsole
python -m unittest discover -s tests -v
```

## Büro-Oberfläche
Jeder Mitarbeiter sitzt an seinem Platz. Beim Projektlauf leuchten die Monitore nacheinander auf, die Ampel zeigt
das Ergebnis (grün / gelb / rot). Klick auf einen Mitarbeiter öffnet:
Befunde, letzte Aktionen, **Anweisung (Prompt) bearbeiten**, Skills bearbeiten (Texte, Compliance, Qualität),
beim Mengen-Mitarbeiter die Zuordnung `mapping.yaml`. Beim Manager: Kennzahlen, **Freigabe**, Downloads.
Jede Änderung wird als `.bak` gesichert und im Audit-Log festgehalten.

Mehrere Arbeitsplätze im Büronetz: in `config.yaml` unter `web` `host: "0.0.0.0"` und ein `token` setzen.
Ohne Token startet der Server dort bewusst nicht. Es gibt keine Benutzerkonten: wer das Token kennt, darf bearbeiten.
Für echten Mehrbenutzerbetrieb (Rollen, Anmeldung) braucht es einen Reverse-Proxy mit Login, z. B. im Firmennetz.

## Informationen sammeln
Button **Informationen sammeln** im Büro: Jeder Agent liest seine Quellen aus `quellen.yaml` (nur Domains aus
`quellen_whitelist` in `config.yaml`, auch bei Weiterleitungen). Gespeichert werden nur kurze Rohauszüge mit Quelle und
Datum als *Vorschlag*. Nichts davon fließt automatisch in Texte, Preise oder LV. Unerreichbare Quellen zeigt das Büro
beim jeweiligen Agenten an. Die Links in `quellen.yaml` bitte prüfen und anpassen (Manager-Platz → Quellenliste).

## Freigabe-Regeln
Freigabe nur, wenn keine Fehler offen sind **und** alle Preise und Texte freigegeben sind (keine Richtpreise,
keine Entwurfstexte). Ändert sich danach ein Text, Preis oder eine Menge, verfällt die Freigabe automatisch.

## Wichtige Grenzen
- IFC- und DWG-Einlesen ist hier nicht mit echten Dateien getestet. Zuerst mit eigenen Modellen prüfen.
- GAEB folgt DA XML 3.3 (manche öffentliche Auftraggeber verlangen noch 3.2, z. B. Niedersachsen: vorher nachfragen), ist aber nicht zertifiziert: gegen das offizielle XSD von gaeb.de prüfen und in einer AVA-Software öffnen.
- Preise und Zuschlagssätze (BGK/AGK/W+G) sind Platzhalter. Öffnungsabzüge nach VOB/C sind nicht berechnet.
- STLB-Bau- und DIN-Texte sind urheberrechtlich geschützt: nur eigene oder lizenzierte Texte importieren.
- Das Selbstverbesserungs-Verfahren (Skill vorschlagen → testen → freigeben) ist technisch vorhanden, der Test
  unterscheidet aber noch kaum zwischen Varianten. Skills nur nach eigener Prüfung freigeben.
- Die 3D-Ansicht ist ein Rundgang durch das IFC-Modell, kein fotorealistisches Video. Benötigt `IfcConvert`.
- Keine Rechtsberatung. Vor jedem Versand menschlich prüfen.
