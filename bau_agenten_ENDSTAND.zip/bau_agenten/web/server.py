"""Buero-Oberflaeche: python main.py buero  ->  http://127.0.0.1:8080
Nur Standardbibliothek. Schreibzugriffe nur auf feste Whitelist (Prompts, Skills, Mapping), Pfade werden geprueft."""
from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

import yaml

from bau_agenten.core.kontext import Kontext
from bau_agenten.manager.manager import Manager

TEAM = [  # id, Anzeigename, Rolle, Prompt-Datei, Skill-Ordner
    ("manager", "Manager", "Leitung, Freigaben, Bericht", "manager", None),
    ("mengen_agent", "Mengen", "Mengen aus IFC/DXF/DWG", "mengen_agent", None),
    ("text_agent", "Texte", "Kurz- und Langtexte", "text_agent", "text_agent"),
    ("kalkulations_agent", "Kalkulation", "Einheitspreise", "kalkulation", None),
    ("lv_agent", "LV", "LV, PDF, GAEB", "lv_agent", None),
    ("compliance_agent", "Compliance", "VOB/A, VOB/C", "compliance", "compliance"),
    ("qa_agent", "Qualität", "Rechen- und Plausibilitaetskontrolle", "qa", "quality"),
    ("visualisierungs_agent", "3D", "Rundgang und Bauphasen", "visualisierung", None),
]


class App:
    def __init__(self, basis: Path):
        self.basis = Path(basis).resolve()
        self.ctx = Kontext.laden(self.basis)
        self.mgr = Manager(self.ctx)
        self.cfg = self.ctx.cfg
        self.lock = threading.Lock()
        self.lauf = {"laeuft": False, "projekt": None, "start": None, "fehler": None, "ergebnis": None}
        self.sam = {"laeuft": False, "ergebnis": None, "zeit": 0}

    # ---- Dateien, die das UI bearbeiten darf (feste Whitelist) ----
    def datei(self, art: str, name: str) -> Path:
        if art == "prompt" and name in {t[3] for t in TEAM}:
            return self.basis / "prompts" / f"{name}.md"
        if art == "skill":
            ordner, _, stem = name.partition("/")
            if ordner in {t[4] for t in TEAM if t[4]}:
                p = self.basis / "skills" / ordner / f"{stem}.md"
                if p.exists() and p.parent.parent == self.basis / "skills":
                    return p
        if art == "quellen" and name == "quellen":
            return self.basis / "quellen.yaml"
        if art == "mapping" and name == "mapping":
            return self.basis / "regeln" / "mapping.yaml"
        raise PermissionError("Datei nicht bearbeitbar")

    def projekte(self) -> list:
        res = []
        for wurzel in ("projekte", "referenzprojekte"):
            d = self.basis / wurzel
            if d.exists():
                res += [f"{wurzel}/{p.name}" for p in sorted(d.iterdir()) if (p / "projekt.yaml").exists()]
        return res

    def projektpfad(self, rel: str) -> Path:
        p = (self.basis / rel).resolve()
        if p.parent.parent != self.basis or not (p / "projekt.yaml").exists():
            raise PermissionError("Ungueltiges Projekt")
        return p

    def starte(self, rel: str, rundgang: bool):
        p = self.projektpfad(rel)
        if not self.ctx.kb.con.execute("SELECT COUNT(*) FROM texte").fetchone()[0]:
            for datei, fn in (("texte.csv", self.ctx.kb.import_texte_csv), ("preise.csv", self.ctx.kb.import_preise_csv)):
                if (p / datei).exists():
                    fn(p / datei)  # Wissensbasis leer: Texte/Preise des Projekts uebernehmen
        if not self.lock.acquire(blocking=False):
            raise RuntimeError("Es laeuft bereits ein Projekt")
        self.lauf = {"laeuft": True, "projekt": rel, "start": time.time(), "fehler": None, "ergebnis": None}

        def job():
            try:
                e = self.mgr.run(p, rundgang)
                self.lauf["ergebnis"] = {
                    "final": e.final, "kennzahlen": {k: v for k, v in e.kennzahlen.items() if k != "laufzeiten"},
                    "offen": self.mgr.offene_punkte(e.lv),
                    "befunde": [vars(b) for b in e.befunde],
                    "dateien": {k: Path(v).name for k, v in e.ausgaben.items()}}
            except Exception as ex:  # Fehler im UI anzeigen statt Server abstuerzen
                self.lauf["fehler"] = f"{type(ex).__name__}: {ex}"
            finally:
                self.lauf["laeuft"] = False
                self.lock.release()
        threading.Thread(target=job, daemon=True).start()

    def sammeln(self):
        if not self.lock.acquire(blocking=False):
            raise RuntimeError("Es laeuft bereits ein Vorgang")
        self.sam = {"laeuft": True, "ergebnis": None, "zeit": time.time()}

        def job():
            try:
                from bau_agenten.agents.sammler import sammle
                self.sam["ergebnis"] = sammle(self.ctx)
            except Exception as ex:
                self.sam["ergebnis"] = {"manager": [{"url": "-", "ok": False, "fehler": str(ex)[:160]}]}
            finally:
                self.sam["zeit"] = time.time()
                self.sam["laeuft"] = False
                self.lock.release()
        threading.Thread(target=job, daemon=True).start()

    def state(self) -> dict:
        start = self.lauf["start"] or 0
        ereignisse = [{"agent": e["agent"], "aktion": e["aktion"], "t": e["zeit"]}
                      for e in self.ctx.audit.eintraege()[-60:]]
        skills = self.ctx.skills.liste()
        team = []
        for aid, name, rolle, prompt, sk in TEAM:
            team.append({"id": aid, "name": name, "rolle": rolle, "prompt": prompt,
                         "skills": [f"{s['agent']}/{s['name']}" for s in skills if sk and s["agent"] == sk]})
        return {"firma": self.cfg["firma"], "team": team, "projekte": self.projekte(), "lauf": self.lauf,
                "sammeln": self.sam, "ereignisse": ereignisse, "jetzt": time.time(), "schreibschutz": bool(self.cfg["web"].get("token"))}


def handler(app: App):
    token = app.cfg["web"].get("token", "")

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code, body, typ="application/json; charset=utf-8", extra=None):
            if not isinstance(body, bytes):
                body = json.dumps(body, ensure_ascii=False, default=str).encode()
            self.send_response(code)
            self.send_header("Content-Type", typ)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _darf_schreiben(self) -> bool:
            return not token or self.headers.get("X-Token") == token

        def do_GET(self):
            pfad = unquote(urlparse(self.path).path)
            try:
                if pfad == "/":
                    return self._send(200, (Path(__file__).parent / "office.html").read_bytes(), "text/html; charset=utf-8")
                if pfad == "/api/state":
                    return self._send(200, app.state())
                if pfad.startswith("/api/wissen/"):
                    return self._send(200, app.ctx.kb.liste_wissen(pfad.rsplit("/", 1)[1]))
                if pfad.startswith("/api/datei/"):
                    _, _, _, art, name = pfad.split("/", 4)
                    return self._send(200, {"text": app.datei(art, name).read_text(encoding="utf-8")})
                if pfad.startswith("/api/ausgabe/"):
                    _, _, _, rel, datei = pfad.split("/", 4)
                    aus = (app.projektpfad(rel.replace("~", "/")) / "ausgabe").resolve()
                    f = (aus / datei).resolve()
                    if f.parent != aus or not f.is_file():
                        raise PermissionError("Datei nicht gefunden")
                    return self._send(200, f.read_bytes(), "application/octet-stream",
                                      {"Content-Disposition": f'attachment; filename="{f.name}"'})
                self._send(404, {"fehler": "nicht gefunden"})
            except Exception as e:
                self._send(400, {"fehler": str(e)})

        def do_POST(self):
            if not self._darf_schreiben():
                return self._send(403, {"fehler": "Token fehlt oder falsch"})
            try:
                n = int(self.headers.get("Content-Length", 0))
                d = json.loads(self.rfile.read(min(n, 1_000_000)) or b"{}")
                pfad = urlparse(self.path).path
                if pfad == "/api/run":
                    app.starte(d["projekt"], bool(d.get("rundgang")))
                    return self._send(200, {"ok": True})
                if pfad == "/api/sammeln":
                    app.sammeln()
                    return self._send(200, {"ok": True})
                if pfad == "/api/freigeben":
                    return self._send(200, app.mgr.freigeben(app.projektpfad(d["projekt"]), d.get("von", "")))
                if pfad == "/api/speichern":
                    p = app.datei(d["art"], d["name"])
                    if d["art"] in ("mapping", "quellen"):
                        yaml.safe_load(d["text"])  # nur gueltiges YAML speichern
                    alt = p.read_text(encoding="utf-8")
                    (p.parent / (p.name + ".bak")).write_text(alt, encoding="utf-8")
                    p.write_text(d["text"], encoding="utf-8")
                    app.ctx.audit.log("manager", "bearbeitet_im_ui", {"datei": f"{d['art']}/{d['name']}"})
                    return self._send(200, {"ok": True})
                self._send(404, {"fehler": "nicht gefunden"})
            except Exception as e:
                self._send(400, {"fehler": str(e)})
    return H


def starte(basis):
    app = App(basis)
    w = app.cfg["web"]
    if w["host"] not in ("127.0.0.1", "localhost") and not w.get("token"):
        raise SystemExit("Abbruch: Server im Netz ohne web.token in config.yaml ist nicht erlaubt.")
    srv = ThreadingHTTPServer((w["host"], int(w["port"])), handler(app))
    print(f"Buero offen: http://{w['host']}:{w['port']}  (Strg+C beendet)")
    srv.serve_forever()
