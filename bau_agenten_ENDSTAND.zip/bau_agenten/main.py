"""Kommandozeile: python main.py <befehl> ..."""
import argparse
import shutil
import sys
import tempfile
from pathlib import Path

from bau_agenten.core.kontext import Kontext
from bau_agenten.manager.manager import Manager

BASIS = Path(__file__).parent


def _ausgabe(erg):
    kz = erg.kennzahlen
    print(f"Status: {'FREIGEGEBEN' if erg.final else 'ENTWURF'} | Positionen {kz['positionen']} | "
          f"Netto {kz['netto']:.2f} EUR | Fehler {kz['fehler']} Warnungen {kz['warnungen']}")
    for k, v in erg.ausgaben.items():
        print(f"  {k}: {v}")
    print(f"  bericht: {erg.bericht}")


def main(argv=None):
    ap = argparse.ArgumentParser(description="Bau-Agenten")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="Projekt verarbeiten")
    r.add_argument("projekt")
    r.add_argument("--rundgang", action="store_true")
    f = sub.add_parser("freigeben", help="LV-Stand freigeben (menschliche Freigabe)")
    f.add_argument("projekt")
    f.add_argument("--von", required=True)
    k = sub.add_parser("kb-import", help="Texte/Preise (CSV, ;-getrennt) importieren")
    k.add_argument("--texte")
    k.add_argument("--preise")
    k.add_argument("--status", default="freigegeben", choices=["freigegeben", "vorschlag"])
    sub.add_parser("buero", help="Buero-Oberflaeche im Browser starten")
    sub.add_parser("demo", help="Demoprojekt mit Beispieldaten ausfuehren")
    a = ap.parse_args(argv)

    if a.cmd == "buero":
        from web.server import starte
        return starte(BASIS)
    ctx = Kontext.laden(BASIS)
    m = Manager(ctx)
    if a.cmd == "run":
        _ausgabe(m.run(a.projekt, a.rundgang))
    elif a.cmd == "freigeben":
        print(m.freigeben(a.projekt, a.von))
    elif a.cmd == "kb-import":
        if a.texte:
            print("Texte importiert:", ctx.kb.import_texte_csv(a.texte, a.status))
        if a.preise:
            print("Preise importiert:", ctx.kb.import_preise_csv(a.preise, a.status))
    elif a.cmd == "demo":
        demo = BASIS / "referenzprojekte" / "demo_buero"
        ctx.kb.import_texte_csv(demo / "texte.csv")
        ctx.kb.import_preise_csv(demo / "preise.csv")
        _ausgabe(m.run(demo))


if __name__ == "__main__":
    sys.exit(main())
