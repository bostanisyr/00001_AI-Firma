import json
import shutil
import tempfile
import unittest
from pathlib import Path

from lxml import etree

from bau_agenten.agents.quantity_agent import QuantityAgent, polygon_flaeche, polygon_umfang
from bau_agenten.agents.text_agent import quelle_erlaubt
from bau_agenten.core.kontext import Kontext
from bau_agenten.core.models import Mengenposten
from bau_agenten.exporte.gaeb import pruefe_gaeb
from bau_agenten.manager.manager import Manager

QUELLE = Path(__file__).resolve().parent.parent


def kopie():
    tmp = Path(tempfile.mkdtemp())
    ziel = tmp / "p"
    shutil.copytree(QUELLE, ziel, ignore=shutil.ignore_patterns("daten", "__pycache__", "ausgabe", "freigabe.json",
                                                                 "_vorschlaege", "_archiv"))
    ctx = Kontext.laden(ziel, tmp / "daten")
    demo = ziel / "referenzprojekte" / "demo_buero"
    ctx.kb.import_texte_csv(demo / "texte.csv")
    ctx.kb.import_preise_csv(demo / "preise.csv")
    return ctx, demo, tmp


class Basis(unittest.TestCase):
    def setUp(self):
        self.ctx, self.demo, self.tmp = kopie()
        self.m = Manager(self.ctx)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


class TestMengen(Basis):
    def test_geometrie(self):
        quadrat = [(0, 0), (4, 0), (4, 3), (0, 3)]
        self.assertAlmostEqual(polygon_flaeche(quadrat), 12.0)
        self.assertAlmostEqual(polygon_umfang(quadrat), 14.0)

    def test_plausibilitaet(self):
        a = QuantityAgent(self.ctx)
        ms = [Mengenposten("1", "R", "IfcSpace", "EG", "R", "NetFloorArea", "m2", 80.0, "t"),
              Mengenposten("2", "D", "IfcSlab", "EG", "", "GrossArea", "m2", 50.0, "t"),
              Mengenposten("3", "X", "IfcWall", "EG", "", "NetSideArea", "m2", 0.0, "t")]
        codes = {b.code for b in a.pruefe(ms)}
        self.assertIn("RAUM_GROESSER_DECKE", codes)
        self.assertIn("MENGE_NULL", codes)

    def test_json_eingabe(self):
        ms = QuantityAgent(self.ctx).run([self.demo / "mengen.json"])
        self.assertEqual(len(ms), 14)

    def test_dxf_optional(self):
        try:
            import ezdxf
        except ImportError:
            self.skipTest("ezdxf nicht installiert")
        doc = ezdxf.new()
        doc.header["$INSUNITS"] = 4
        doc.modelspace().add_lwpolyline([(0, 0), (4000, 0), (4000, 3000), (0, 3000)], close=True,
                                        dxfattribs={"layer": "RAUM"})
        p = self.tmp / "t.dxf"
        doc.saveas(p)
        ms = QuantityAgent(self.ctx).run([p])
        self.assertAlmostEqual(next(m.wert for m in ms if m.menge_name == "NetFloorArea"), 12.0, places=3)


class TestWissensbasis(Basis):
    def test_versionen_und_status(self):
        kb = self.ctx.kb
        v = kb.add_text("X", "01", "k", "l", "m2", status="vorschlag")
        self.assertEqual(kb.get_text("X")["status"], "vorschlag")
        self.assertIsNone(kb.get_text("X", nur_freigegeben=True))
        kb.freigeben_text(v)
        self.assertEqual(kb.get_text("X", nur_freigegeben=True)["version"], 1)

    def test_whitelist(self):
        wl = self.ctx.cfg["quellen_whitelist"]
        self.assertTrue(quelle_erlaubt("https://www.gaeb.de/x", wl))
        self.assertFalse(quelle_erlaubt("https://evil.example.com/gaeb.de", wl))
        self.assertFalse(quelle_erlaubt("https://gaeb.de.evil.com/", wl))


class TestPipeline(Basis):
    def test_entwurf_dann_freigabe(self):
        e1 = self.m.run(self.demo)
        self.assertFalse(e1.final)
        self.assertEqual(e1.kennzahlen["positionen"], 6)
        self.assertEqual(e1.kennzahlen["fehler"], 0, [b for b in e1.befunde if b.schwere == "Fehler"])
        self.assertTrue(Path(e1.ausgaben["pdf"]).name.endswith("_ENTWURF.pdf"))
        self.m.freigeben(self.demo, "Tester")
        e2 = self.m.run(self.demo)
        self.assertTrue(e2.final)
        self.assertTrue(Path(e2.ausgaben["gaeb_x84"]).name == "LV.x84")

    def test_freigabe_ungueltig_nach_aenderung(self):
        self.m.run(self.demo)
        self.m.freigeben(self.demo, "Tester")
        self.ctx.kb.add_preis("TB_WAND_CW75_1L", 99.0, status="freigegeben", gueltig_ab="2026-06-01")
        self.assertFalse(self.m.run(self.demo).final)

    def test_rechnung(self):
        e = self.m.run(self.demo)
        lv = e.lv
        tb = next(p for p in lv.positionen if p.text_key == "TB_WAND_CW75_1L")
        self.assertAlmostEqual(tb.menge, 240.0)
        self.assertAlmostEqual(tb.gp, 240.0 * 45.0)
        self.assertAlmostEqual(lv.netto(), sum(p.gp for p in lv.positionen), places=2)
        tuer = next(p for p in lv.positionen if p.text_key == "TI_TUER_INNEN")
        self.assertEqual(tuer.menge, 8)

    def test_gaeb(self):
        e = self.m.run(self.demo)
        for k in ("gaeb_x83", "gaeb_x84"):
            self.assertEqual(pruefe_gaeb(e.ausgaben[k]), [])
        baum = etree.parse(e.ausgaben["gaeb_x84"])
        ns = {"g": "http://www.gaeb.de/GAEB_DA_XML/DA84/3.3"}
        self.assertEqual(len(baum.findall(".//g:Item", ns)), 6)
        x83 = etree.parse(e.ausgaben["gaeb_x83"])
        self.assertEqual(x83.findall(".//{*}UP"), [])
        total = sum(float(x.text) for x in baum.findall(".//g:IT", ns))
        self.assertAlmostEqual(total, e.lv.netto(), places=1)

    def test_gaeb_defekt_wird_erkannt(self):
        p = self.tmp / "kaputt.x83"
        p.write_text("<GAEB><x></GAEB>")
        self.assertTrue(pruefe_gaeb(p))

    def test_pdf(self):
        e = self.m.run(self.demo)
        daten = Path(e.ausgaben["pdf"]).read_bytes()
        self.assertTrue(daten.startswith(b"%PDF"))
        self.assertGreater(len(daten), 2000)

    def test_bericht_und_audit(self):
        e = self.m.run(self.demo)
        text = Path(e.bericht).read_text(encoding="utf-8")
        self.assertIn("Verbesserungsvorschlaege", text)
        self.assertIn("ENTWURF", text)
        aktionen = {a["aktion"] for a in self.ctx.audit.eintraege()}
        self.assertTrue({"lv_gebaut", "exportiert", "projekt_abgeschlossen"} <= aktionen)

    def test_fehlender_preis_und_text(self):
        self.ctx.kb.con.execute("DELETE FROM preise WHERE text_key='MA_DISP_WAND'")
        self.ctx.kb.con.execute("DELETE FROM texte WHERE text_key='BB_VINYL_DESIGN'")
        self.ctx.kb.con.commit()
        e = self.m.run(self.demo)
        self.assertEqual(e.kennzahlen["ohne_preis"], 1)
        self.assertEqual(e.kennzahlen["ohne_text"], 1)
        self.assertFalse(e.final)


class TestCompliance(Basis):
    def test_regeln(self):
        e = self.m.run(self.demo)
        p = e.lv.positionen[0]
        p.langtext += " ca. 10 mm, Fabrikat: Muster, Risiko trägt der AN."
        p.kurztext = "x" * 80
        p.din_refs = []
        codes = {b.code for b in self.m.compliance.pruefe(e.lv)}
        self.assertTrue({"UNKLAR", "WAGNIS", "PRODUKT_OHNE_GLEICHWERTIG", "KURZTEXT_LANG", "ATV_FEHLT"} <= codes)

    def test_qa(self):
        e = self.m.run(self.demo)
        e.lv.positionen[0].ep = 999.0
        e.lv.positionen[1].langtext = "TODO"
        codes = {b.code for b in self.m.qa.pruefe(e.lv)}
        self.assertTrue({"PREIS_AUSREISSER", "PLATZHALTER"} <= codes)


class TestKalkulation(Basis):
    def test_zuschlag(self):
        ep = self.m.preis_agent.ep_aus_kalk(lohn_min=30, stoff=10.0, geraete=1.0)
        k = self.ctx.cfg["kalkulation"]
        ekt = 30 / 60 * k["stundenverrechnungssatz"] + 11.0
        self.assertAlmostEqual(ep, round(ekt * 1.08 * 1.10 * 1.06, 2))


class TestSelbstentwicklung(Basis):
    def test_ablauf_mit_freigabe(self):
        reg = self.ctx.skills
        vid = self.m.neuer_skill("text_agent", "neuer_skill", "Neue Regel.", "Test")
        stufen = iter([{"fehler": 2, "qa_fehler": 0, "abdeckung": 0.8}, {"fehler": 1, "qa_fehler": 0, "abdeckung": 0.9}])
        b = reg.bewerten(vid, lambda _t: next(stufen))
        self.assertTrue(b["bestanden"])
        with self.assertRaises(PermissionError):
            reg.uebernehmen(vid)                       # ohne menschliche Freigabe
        pfad = reg.uebernehmen(vid, freigabe_durch="Ali")
        self.assertTrue(pfad.exists())
        self.assertIn("Neue Regel.", reg.aktiver_text("text_agent"))

    def test_verschlechterung_wird_abgelehnt(self):
        reg = self.ctx.skills
        vid = self.m.neuer_skill("text_agent", "schlecht", "x", "Test")
        stufen = iter([{"fehler": 1, "qa_fehler": 0, "abdeckung": 1.0}, {"fehler": 3, "qa_fehler": 0, "abdeckung": 1.0}])
        self.assertFalse(reg.bewerten(vid, lambda _t: next(stufen))["bestanden"])
        with self.assertRaises(PermissionError):
            reg.uebernehmen(vid, freigabe_durch="Ali")

    def test_geschuetzte_pfade(self):
        reg = self.ctx.skills
        with self.assertRaises(PermissionError):
            reg._pruefe_pfad(self.ctx.basis / "config.yaml")
        with self.assertRaises(PermissionError):
            reg._pruefe_pfad(self.ctx.basis / "regeln" / "compliance.yaml")

    def test_rollback(self):
        reg = self.ctx.skills
        vid = self.m.neuer_skill("text_agent", "langtext_struktur", "Version 2", "Test")
        stufen = iter([{"fehler": 1, "qa_fehler": 0, "abdeckung": 0.5}, {"fehler": 0, "qa_fehler": 0, "abdeckung": 0.5}])
        reg.bewerten(vid, lambda _t: next(stufen))
        reg.uebernehmen(vid, freigabe_durch="Ali")
        self.assertIn("Version 2", reg.aktiver_text("text_agent"))
        reg.zurueckrollen("text_agent", "langtext_struktur")
        self.assertNotIn("Version 2", reg.aktiver_text("text_agent"))

    def test_bewertung_an_referenzprojekten(self):
        fn = self.m.bewertungsfunktion(self.ctx.basis / "referenzprojekte")
        k = fn(None)
        self.assertEqual(k["fehler"], 0)
        self.assertEqual(k["abdeckung"], 1.0)


class TestNeueRegeln(unittest.TestCase):
    def test_skill_mit_windows_zeilenenden(self):
        from bau_agenten.manager.improvement import SkillRegistry
        meta, body = SkillRegistry._parse("---\r\nname: x\r\n---\r\nText")
        self.assertEqual(meta["name"], "x")

    def test_etwa_trifft_nicht_etwas(self):
        import re
        self.assertIsNone(re.search(r"(?<!\w)etwa(?!\w)", "etwas anderes"))

    def test_redirect_ausserhalb_whitelist(self):
        from bau_agenten.agents.text_agent import _NurWhitelist
        h = _NurWhitelist(["gaeb.de"])
        with self.assertRaises(PermissionError):
            h.redirect_request(None, None, 302, "", {}, "https://evil.example/x")

    def test_freigabe_nur_mit_freigegebenen_preisen(self):
        from bau_agenten.manager.manager import Manager
        from bau_agenten.core.models import LV, Position
        lv = LV({}, [])
        lv.positionen.append(Position("01.0010", "01", "k", "k", "l", "m2", 1.0, 5.0, preis_status="richtpreis"))
        self.assertTrue(Manager.offene_punkte(lv))


if __name__ == "__main__":
    unittest.main()


class TestSammler(unittest.TestCase):
    def test_sammeln_speichert_vorschlag_und_toleriert_fehler(self):
        import tempfile
        from unittest import mock
        from bau_agenten.core.kontext import Kontext
        from bau_agenten.agents import sammler
        with tempfile.TemporaryDirectory() as d:
            ctx = Kontext.laden(Path(__file__).resolve().parent.parent, daten_dir=d)
            def fake(url, wl, limit=1500):
                if "gwb" in url:
                    raise OSError("offline")
                return "Beispielauszug " + url
            with mock.patch.object(sammler, "hole_auszug", fake):
                erg = sammler.sammle(ctx)
                erg2 = sammler.sammle(ctx)
            alle = [x for v in erg.values() for x in v]
            self.assertTrue(any(x["ok"] for x in alle) and any(not x["ok"] for x in alle))
            self.assertFalse(any(x.get("neu") for v in erg2.values() for x in v))   # unveraendert -> nicht doppelt
            self.assertTrue(ctx.kb.liste_wissen("compliance_agent"))

    def test_whitelist_gilt_auch_beim_sammeln(self):
        from bau_agenten.agents.text_agent import hole_auszug
        with self.assertRaises(PermissionError):
            hole_auszug("https://evil.example/", ["gaeb.de"])
